<?php

require_once __DIR__ . '/config.php';

function funyapi_site_start_session()
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $isSecure = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
    session_name('funyapi_site');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

function funyapi_site_csrf_token()
{
    funyapi_site_start_session();
    if (empty($_SESSION['funyapi_csrf'])) {
        $_SESSION['funyapi_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['funyapi_csrf'];
}

function funyapi_site_check_csrf($token)
{
    funyapi_site_start_session();
    return isset($_SESSION['funyapi_csrf'])
        && is_string($token)
        && hash_equals($_SESSION['funyapi_csrf'], $token);
}

function funyapi_site_check_origin()
{
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? trim((string) $_SERVER['HTTP_ORIGIN']) : '';
    if ($origin === '') {
        $origin = isset($_SERVER['HTTP_REFERER']) ? trim((string) $_SERVER['HTTP_REFERER']) : '';
    }
    if ($origin === '') {
        return true;
    }

    $originHost = parse_url($origin, PHP_URL_HOST);
    $requestHost = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', (string) $_SERVER['HTTP_HOST']) : '';
    return is_string($originHost)
        && $requestHost !== ''
        && hash_equals(strtolower($requestHost), strtolower($originHost));
}

function funyapi_site_escape($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function funyapi_site_admin_emails()
{
    $emails = array_map('trim', explode(',', SITE_ADMIN_EMAILS));
    $emails = array_map('strtolower', $emails);
    return array_values(array_filter($emails, function ($email) {
        return $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL);
    }));
}

function funyapi_site_is_admin($account)
{
    if (!is_array($account) || !isset($account['is_active']) || (int) $account['is_active'] !== 1) {
        return false;
    }

    $email = isset($account['email']) ? strtolower((string) $account['email']) : '';
    $telegramId = isset($account['telegram_user_id']) ? (string) $account['telegram_user_id'] : '';
    return ($email !== '' && in_array($email, funyapi_site_admin_emails(), true))
        || (BOT_ADMIN_ID !== '' && $telegramId !== '' && hash_equals(BOT_ADMIN_ID, $telegramId));
}

/** Create the bot's canonical user row once; the website and webhook call this same helper. */
function funyapi_ensure_bot_user($connect, $telegramUserId)
{
    $telegramUserId = (string) $telegramUserId;
    if (!preg_match('/^[1-9][0-9]{0,19}$/', $telegramUserId)) {
        return false;
    }

    $lockName = 'funyapi_user_' . substr(hash('sha256', $telegramUserId), 0, 40);
    $lock = mysqli_prepare($connect, 'SELECT GET_LOCK(?, 3)');
    if (!$lock) {
        return false;
    }
    $lockAcquired = 0;
    mysqli_stmt_bind_param($lock, 's', $lockName);
    mysqli_stmt_execute($lock);
    mysqli_stmt_bind_result($lock, $lockAcquired);
    mysqli_stmt_fetch($lock);
    mysqli_stmt_close($lock);
    if ((int) $lockAcquired !== 1) {
        return false;
    }

    $existing = mysqli_prepare($connect, 'SELECT user_id FROM users WHERE id = ? LIMIT 1');
    if ($existing) {
        mysqli_stmt_bind_param($existing, 's', $telegramUserId);
        mysqli_stmt_execute($existing);
        mysqli_stmt_store_result($existing);
        $found = mysqli_stmt_num_rows($existing) > 0;
        mysqli_stmt_close($existing);
        if ($found) {
            $release = mysqli_prepare($connect, 'SELECT RELEASE_LOCK(?)');
            if ($release) {
                mysqli_stmt_bind_param($release, 's', $lockName);
                mysqli_stmt_execute($release);
                mysqli_stmt_close($release);
            }
            return true;
        }
    }

    $counter = mysqli_query($connect, 'UPDATE settings SET users = LAST_INSERT_ID(GREATEST(users, COALESCE((SELECT MAX(user_id) FROM users), 0)) + 1) WHERE id = 1');
    $internalId = $counter ? (int) mysqli_insert_id($connect) : 0;
    if ($internalId < 1) {
        $next = mysqli_query($connect, 'SELECT COALESCE(MAX(user_id), 0) + 1 AS next_id FROM users');
        $nextRow = $next ? mysqli_fetch_assoc($next) : null;
        $internalId = $nextRow ? (int) $nextRow['next_id'] : 0;
    }

    $apiKey = bin2hex(random_bytes(32));
    $referral = bin2hex(random_bytes(4));
    $inserted = false;
    if ($internalId > 0) {
        $insert = mysqli_prepare($connect, "INSERT IGNORE INTO users (user_id, id, status, balance, outing, api_key, api_status, referal, refnum, ban) VALUES (?, ?, 'active', '0', '0', ?, 'on', ?, 0, 0)");
        if ($insert) {
            mysqli_stmt_bind_param($insert, 'isss', $internalId, $telegramUserId, $apiKey, $referral);
            $inserted = mysqli_stmt_execute($insert) && mysqli_stmt_affected_rows($insert) === 1;
            mysqli_stmt_close($insert);
        }
    }

    $release = mysqli_prepare($connect, 'SELECT RELEASE_LOCK(?)');
    if ($release) {
        mysqli_stmt_bind_param($release, 's', $lockName);
        mysqli_stmt_execute($release);
        mysqli_stmt_close($release);
    }

    if ($inserted) {
        return true;
    }
    $check = mysqli_prepare($connect, 'SELECT user_id FROM users WHERE id = ? LIMIT 1');
    if (!$check) {
        return false;
    }
    mysqli_stmt_bind_param($check, 's', $telegramUserId);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    $exists = mysqli_stmt_num_rows($check) > 0;
    mysqli_stmt_close($check);
    return $exists;
}

function funyapi_site_notify_admin($message)
{
    if (API_KEY === '' || BOT_ADMIN_ID === '' || !function_exists('curl_init')) {
        return false;
    }

    $ch = curl_init('https://api.telegram.org/bot' . API_KEY . '/sendMessage');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'chat_id' => BOT_ADMIN_ID,
            'text' => substr((string) $message, 0, 3500),
            'disable_web_page_preview' => 'true'
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 6,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2
    ]);
    $response = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $response !== false && $status >= 200 && $status < 300;
}

function funyapi_site_log_event($connect, $eventType, $detail = '', $accountId = null, $notify = false)
{
    $eventType = preg_replace('/[^a-z0-9_]/i', '_', (string) $eventType);
    $eventType = substr($eventType, 0, 48);
    $detail = substr(trim((string) $detail), 0, 1000);
    $accountId = $accountId === null ? null : (int) $accountId;
    $createdAt = date('Y-m-d H:i:s');

    $statement = mysqli_prepare($connect, 'INSERT INTO site_events (account_id, event_type, detail, created_at) VALUES (?, ?, ?, ?)');
    if ($statement) {
        mysqli_stmt_bind_param($statement, 'isss', $accountId, $eventType, $detail, $createdAt);
        mysqli_stmt_execute($statement);
        mysqli_stmt_close($statement);
    }

    if ($notify) {
        $safeDetail = preg_replace('/[\r\n\t]+/', ' ', $detail);
        funyapi_site_notify_admin("FunyAPI: $eventType\n$safeDetail\n$createdAt");
    }
}

function funyapi_site_verify_turnstile($token)
{
    if (TURNSTILE_SECRET_KEY === '' || !is_string($token) || $token === '' || strlen($token) > 2048 || !function_exists('curl_init')) {
        return false;
    }

    $fields = [
        'secret' => TURNSTILE_SECRET_KEY,
        'response' => $token
    ];
    if (!empty($_SERVER['REMOTE_ADDR'])) {
        $fields['remoteip'] = $_SERVER['REMOTE_ADDR'];
    }

    $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2
    ]);
    $response = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false || $status !== 200) {
        return false;
    }
    $result = json_decode($response, true);
    if (!is_array($result) || empty($result['success'])) {
        return false;
    }

    $host = isset($_SERVER['HTTP_HOST']) ? strtolower(preg_replace('/:\d+$/', '', (string) $_SERVER['HTTP_HOST'])) : '';
    if ($host !== '' && isset($result['hostname']) && strtolower((string) $result['hostname']) !== $host) {
        return false;
    }
    return true;
}

function funyapi_site_verify_google_credential($credential)
{
    if (GOOGLE_CLIENT_ID === '' || !is_string($credential) || $credential === '' || strlen($credential) > 8192 || !function_exists('curl_init')) {
        return false;
    }

    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($credential);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2
    ]);
    $response = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false || $status !== 200) {
        return false;
    }
    $claims = json_decode($response, true);
    if (!is_array($claims)
        || !isset($claims['aud'], $claims['iss'], $claims['exp'], $claims['sub'], $claims['email'])
        || !hash_equals(GOOGLE_CLIENT_ID, (string) $claims['aud'])
        || !in_array((string) $claims['iss'], ['accounts.google.com', 'https://accounts.google.com'], true)
        || (int) $claims['exp'] <= time()
        || empty($claims['email_verified'])
        || !filter_var((string) $claims['email'], FILTER_VALIDATE_EMAIL)
        || !preg_match('/^[0-9]{10,30}$/', (string) $claims['sub'])) {
        return false;
    }

    return [
        'google_sub' => (string) $claims['sub'],
        'email' => strtolower((string) $claims['email']),
        'display_name' => isset($claims['name']) ? substr((string) $claims['name'], 0, 200) : (string) $claims['email']
    ];
}

function funyapi_site_current_account($connect)
{
    funyapi_site_start_session();
    $accountId = isset($_SESSION['funyapi_account_id']) ? (int) $_SESSION['funyapi_account_id'] : 0;
    if ($accountId < 1) {
        return null;
    }

    $statement = mysqli_prepare($connect, 'SELECT account_id, google_sub, email, display_name, role, is_active, telegram_user_id, created_at, last_login FROM site_accounts WHERE account_id = ? LIMIT 1');
    if (!$statement) {
        return null;
    }
    mysqli_stmt_bind_param($statement, 'i', $accountId);
    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $account = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);

    if (!$account || (int) $account['is_active'] !== 1) {
        $_SESSION = [];
        session_regenerate_id(true);
        return null;
    }
    return $account;
}

function funyapi_site_require_account($connect)
{
    $account = funyapi_site_current_account($connect);
    if (!$account) {
        header('Location: /login');
        exit;
    }
    return $account;
}

function funyapi_site_require_admin($connect)
{
    $account = funyapi_site_require_account($connect);
    if (!funyapi_site_is_admin($account)) {
        http_response_code(403);
        exit('Bu sahifa administratorlar uchun.');
    }
    return $account;
}

