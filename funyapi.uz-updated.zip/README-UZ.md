# FunyAPI · yagona sayt va Telegram bot

FunyAPI sayti va Telegram boti **bitta PHP backend va bitta MySQL/MariaDB bazasi** bilan ishlaydi. Alohida sayt bazasi yoki ikkinchi buyurtma tizimi yo‘q: balans, API kalit, xizmatlar va buyurtmalar `users`, `services`, `providers`, `myorder`, `orders`, `neworder` jadvallaridan olinadi. `site_accounts` faqat Google/Telegram kirish ma’lumotlarini shu botdagi Telegram hisobiga bog‘laydi; `site_events` esa sayt va bot faolligi bo‘yicha audit yozuvlarini saqlaydi.

## Vultr VPS’da joylashtirish

1. Vultr’da Ubuntu 24.04 LTS VPS yarating, SSH kaliti bilan kiring va domeningizning `A` yozuvini VPS IPv4 manziliga yo‘naltiring. Vultr’ning [Ubuntu 24.04 LEMP qo‘llanmasi](https://docs.vultr.com/how-to-install-nginx-mysql-php-lemp-stack-on-ubuntu-24-04) Nginx, MySQL, PHP-FPM, firewall va TLS sertifikatini sozlashni ko‘rsatadi.
2. Nginx, MySQL va kerakli PHP modullarini o‘rnating: `php-fpm`, `php-mysql`, `php-curl`, `php-mbstring`. PHP-FPM soket nomi serverdagi PHP versiyasiga bog‘liq.
3. ZIP’ni masalan `/var/www/funyapi` ichiga chiqaring. Nginx `root` aynan shu katalog bo‘lsin. Ushbu loyihaning asosiy kirish fayli ildizdagi `index.php`.
4. Nginx virtual hostda `location / { try_files $uri $uri/ /index.php?$query_string; }` qoidasini qo‘ying. `.htaccess` faqat Apache uchun; Nginx uni o‘qimaydi. PHP fayllarini PHP-FPM’ga uzating. `.env`, `.git`, `app/`, `set/`, `user/`, `number/` kataloglariga HTTP orqali kirishni rad eting; `bot/bot.php` webhook uchun ochiq qoladi.
5. MySQL’da alohida baza va cheklangan huquqli foydalanuvchi yarating. Yangi baza bo‘lsa `app/db.sql` ni bir marta import qiling. Mavjud FunyAPI bazasi bo‘lsa avval zaxira oling, so‘ng `app/db_migration_2026_10.sql` ni bir marta ishga tushiring. Eski bot foydalanuvchilari va buyurtmalar ayni bazada qoladi.
6. .env.example faylidan loyiha ildizida .env nusxa oling. DB_*, Telegram, Google, Turnstile va administrator qiymatlarini o‘zingiznikiga almashtiring. Provider API URL va kalitlarini botdagi mavjud provider sozlamalarida saqlang. Faylga faqat PHP-FPM o‘qiy oladigan huquq bering; uni Git, web orqali ochiq papka yoki ZIP ichiga qo‘ymang.
7. HTTPS sertifikati o‘rnatilib `https://funyapi.uz` ishlagach, Google Cloud OAuth Web client’da `https://funyapi.uz` JavaScript originini kiriting. Cloudflare Turnstile’da `funyapi.uz` uchun widget ochib Site Key va Secret Key’ni `.env` ga qo‘ying.
8. Telegram’da `@BotFather` → `/setdomain` orqali `funyapi.uz` domenini bot loginiga ruxsat eting. `TELEGRAM_BOT_USERNAME` bot username bilan aynan mos bo‘lsin. Sayt sahifasidagi Telegram kirishi rasmiy Telegram Login Widget imzosini serverda tekshiradi.
9. Telegram webhook URL’i `https://funyapi.uz/bot/bot.php` bo‘lishi kerak. Bot tokenni hech qachon ochiq URL, skrinshot yoki chatga joylamang. Bot webhook’ini serverdagi Telegram Bot API chaqiruvi orqali ulang; tokenni faqat maxfiy muhit o‘zgaruvchisidan oling.
10. `.env` sozlangandan va migration bajarilgandan keyin saytda `/login`, foydalanuvchi kabinetida `/account`, administrator kabinetida `/admin` sahifalarini oching. Bot administratori `/site_status` va `/site_events` bilan saytdagi ko‘rsatkichlarni ko‘ra oladi.

### Nginx uchun asosiy yo‘nalish

Quyidagi namuna `$root` o‘rniga sizning loyiha papkangizni va `fastcgi_pass` o‘rniga serverdagi PHP-FPM soketini qo‘yishni talab qiladi:

```nginx
server {
    listen 80;
    server_name funyapi.uz www.funyapi.uz;
    root /var/www/funyapi;
    index index.php;

    location ~ /\.(?!well-known) { deny all; }
    location = /.env.example { deny all; }
    location ~ ^/(app|set|user|number)(/|$) { deny all; }
    location ~ ^/bot/(user|set|number)(/|$) { deny all; }

    location / { try_files $uri $uri/ /index.php?$query_string; }
    location ~ \.php$ {
        try_files $uri =404;
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php-fpm.sock;
    }
}
```

TLS sozlangandan keyin HTTP’dan HTTPS’ga yo‘naltirishni yoqing. MySQL portini internetga ochmang. Botning `user/`, `set/`, `number/` holat kataloglariga PHP-FPM foydalanuvchisi yozishi kerak; bu kataloglarni web’dan yopiq saqlang.

## Kirish, CAPTCHA va hisob ulash

- Google tugmasi Google Identity Services’dan ID token oladi; server audience, issuer, amal qilish va tasdiqlangan emailni tekshiradi.
- Telegram tugmasi rasmiy login widgetidan kelgan imzolangan ma’lumotni bot tokeni asosida tekshiradi. BotFather’da domenni ruxsat qilish talab etiladi.
- Har ikki login Cloudflare Turnstile javobi serverda tasdiqlanmaguncha qabul qilinmaydi.
- Google orqali ro‘yxatdan o‘tgan hisob balansga va botdagi buyurtmalarga kirishi uchun uni o‘sha Telegram hisobiga bir martalik havola bilan ulaydi. Havola 15 daqiqada tugaydi; kod faqat xesh ko‘rinishida bazada turadi.
- Telegram orqali kirish bot foydalanuvchisini ham bazada yaratadi. Admin email’larini `SITE_ADMIN_EMAILS` vergul bilan ajratib yozing. `BOT_ADMIN_ID` ga ulangan Telegram hisobiga ham sayt admin paneli ochiladi.

## Bitta hisobdagi buyurtmalar

Sayt checkout `services` jadvalidagi faqat faol xizmatlardan xizmat, miqdor, narx va limitlarni oladi. Telegram hisobidagi balans tranzaksiya ichida tekshiriladi va ajratiladi; provider HTTPS so‘rovi muvaffaqiyatsiz bo‘lsa mablag‘ qaytariladi. Provider qabul qilgan buyurtma `myorder`, `orders`, `neworder` jadvallariga yoziladi. Bot va sayt buyurtmalari bir xil ID ketma-ketligi hamda foydalanuvchi kalitidan foydalanadi.

Sayt orqali checkout uchun provider API manzillari HTTPS bo‘lishi kerak. Provider API kalitlari va SMS provayder kaliti faqat server bazasi yoki maxfiy `.env` sozlamalarida tursin.

## API misollar

API endpoint: `https://funyapi.uz/api/v2`. API kalitni `/account` sahifasidan oling va server muhitida `FUNYAPI_KEY` sifatida saqlang. PHP, Python va cURL misollari `/api` sahifasida bor. Buyurtma parametrlari: `key`, `action=add`, `service`, `link`, `quantity`.

## Bot orqali admin monitoringi

- `/site_status` — foydalanuvchilar, buyurtmalar, faol xizmatlar va sayt hodisalari soni.
- `/site_events` — so‘nggi kirishlar, yordam murojaatlari va sayt yoki botdan qabul qilingan buyurtmalar.
- Saytdagi `/admin` ham umumiy MySQL bazasidagi buyurtma va foydalanuvchilarni ko‘rsatadi.

## Muammo bo‘lsa

- `/account` balans yoki buyurtma ko‘rsatmasa, bot tokeni, DB sozlamalari va migration’ni tekshiring; sayt va bot `.env` ning bir xil nusxasi va ayni `DB_NAME` bilan ishlashi kerak.
- Google/Telegram kirishi ishlamasa: domen, HTTPS, Google origin, BotFather `/setdomain` va Turnstile hostname’larini tekshiring.
- Sayt buyurtmasi rad etilsa: faol xizmat, minimal/maksimal miqdor, balans va provider HTTPS/API sozlamasini tekshiring. Provider javobi bo‘lmasa, backend yechilgan summani qaytaradi.
- Admin paneli 403 bersa: Telegram admin ID’si `BOT_ADMIN_ID` ga mosligini yoki Google email’i `SITE_ADMIN_EMAILS` da borligini tekshiring.
