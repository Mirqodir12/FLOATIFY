<?php

require_once __DIR__ . '/sql_connect.php';
require_once dirname(__DIR__) . '/site_support.php';

date_default_timezone_set('Asia/Tashkent');
funyapi_site_start_session();

$siteRoute = isset($route[0]) ? $route[0] : 'account';
$siteLanguage = isset($_GET['lang']) ? strtolower((string) $_GET['lang']) : (isset($_SESSION['funyapi_lang']) ? $_SESSION['funyapi_lang'] : 'uz');
if (!in_array($siteLanguage, ['uz', 'ru', 'en'], true)) {
    $siteLanguage = 'uz';
}
$_SESSION['funyapi_lang'] = $siteLanguage;

function funyapi_site_t($key)
{
    global $siteLanguage;
    $text = [
        'uz' => [
            'home' => 'Bosh sahifa', 'services' => 'Xizmatlar', 'api' => 'API', 'bot' => 'Telegram bot',
            'login' => 'Kirish', 'account' => 'Hisobim', 'orders' => 'Buyurtmalar', 'admin' => 'Admin panel',
            'support' => 'Yordam', 'logout' => 'Chiqish', 'login_title' => 'Bitta hisob. Sayt va bot birga.',
            'login_desc' => 'Telegram hisobingiz orqali botdagi balans, API kaliti va buyurtmalarni saytda ham boshqaring.',
            'telegram_login' => 'Telegram orqali kirish', 'google_login' => 'Google orqali kirish',
            'captcha_setup' => 'Kirishdan oldin Google Client ID va Cloudflare Turnstile kalitlarini .env faylida sozlang.',
            'linked' => 'Telegram hisob ulangan', 'not_linked' => 'Hisob hali Telegram botga ulanmagan.',
            'balance' => 'Balans', 'api_key' => 'API kaliti', 'copy' => 'Nusхalash', 'service' => 'Xizmat',
            'link' => 'Havola', 'quantity' => 'Miqdor', 'place_order' => 'Buyurtma berish',
            'min' => 'Min', 'max' => 'Maks', 'price' => 'Narx', 'status' => 'Holat',
            'date' => 'Sana', 'order_id' => 'Buyurtma ID', 'no_orders' => 'Buyurtmalar hali yo‘q.',
            'connect_google' => 'Google hisobni ulash', 'connect_telegram' => 'Telegram hisobni ulash',
            'link_telegram' => 'Botga ulash', 'link_help' => 'Tugmani bosing va botga ochilgan havola orqali /start yuboring. Kod 15 daqiqadan so‘ng bekor bo‘ladi.',
            'analytics' => 'Tizim ko‘rsatkichlari', 'users' => 'Foydalanuvchilar', 'total_orders' => 'Buyurtmalar',
            'pending' => 'Jarayonda', 'revenue' => 'Buyurtma summasi', 'recent_events' => 'So‘nggi hodisalar',
            'recent_orders' => 'So‘nggi buyurtmalar', 'status_online' => 'Bitta baza • Bot va sayt ulangan',
            'support_title' => 'Yordam bilan bog‘lanish', 'support_message' => 'Xabaringiz', 'send' => 'Yuborish',
            'support_sent' => 'Xabaringiz administratorga yuborildi.', 'login_required' => 'Avval hisobingizga kiring.',
            'unavailable' => 'Hozircha bu amal bajarilmadi. Sozlamalarni tekshiring yoki yordamga yozing.',
            'order_success' => 'Buyurtma qabul qilindi.', 'topup_bot' => 'Balansni bot orqali to‘ldiring',
            'language' => 'Til', 'no_services' => 'Faol xizmatlar topilmadi.', 'search' => 'Xizmat qidirish',
            'google_error' => 'Google kirishi tasdiqlanmadi. Qayta urinib ko‘ring.',
            'telegram_error' => 'Telegram tasdiqlanmadi. Bot domenini BotFather orqali sozlang.',
            'captcha_error' => 'CAPTCHA tekshiruvi o‘tmadi. Yana bir bor urinib ko‘ring.',
            'signout' => 'Hisobdan chiqish', 'logged_out' => 'Hisobdan chiqdingiz.',
        ],
        'ru' => [
            'home' => 'Главная', 'services' => 'Услуги', 'api' => 'API', 'bot' => 'Telegram бот',
            'login' => 'Войти', 'account' => 'Мой аккаунт', 'orders' => 'Заказы', 'admin' => 'Админ-панель',
            'support' => 'Поддержка', 'logout' => 'Выйти', 'login_title' => 'Один аккаунт. Сайт и бот вместе.',
            'login_desc' => 'Управляйте балансом, API-ключом и заказами Telegram-бота на сайте.',
            'telegram_login' => 'Войти через Telegram', 'google_login' => 'Войти через Google',
            'captcha_setup' => 'Сначала настройте Google Client ID и ключи Cloudflare Turnstile в .env.',
            'linked' => 'Telegram аккаунт подключён', 'not_linked' => 'Аккаунт ещё не подключён к Telegram-боту.',
            'balance' => 'Баланс', 'api_key' => 'API-ключ', 'copy' => 'Копировать', 'service' => 'Услуга',
            'link' => 'Ссылка', 'quantity' => 'Количество', 'place_order' => 'Создать заказ',
            'min' => 'Мин', 'max' => 'Макс', 'price' => 'Цена', 'status' => 'Статус',
            'date' => 'Дата', 'order_id' => 'ID заказа', 'no_orders' => 'Заказов пока нет.',
            'connect_google' => 'Подключить Google', 'connect_telegram' => 'Подключить Telegram',
            'link_telegram' => 'Подключить бота', 'link_help' => 'Нажмите кнопку и отправьте /start в открывшемся боте. Код истечёт через 15 минут.',
            'analytics' => 'Показатели системы', 'users' => 'Пользователи', 'total_orders' => 'Заказы',
            'pending' => 'В обработке', 'revenue' => 'Сумма заказов', 'recent_events' => 'Последние события',
            'recent_orders' => 'Последние заказы', 'status_online' => 'Одна база данных • сайт и бот связаны',
            'support_title' => 'Связаться с поддержкой', 'support_message' => 'Ваше сообщение', 'send' => 'Отправить',
            'support_sent' => 'Сообщение отправлено администратору.', 'login_required' => 'Сначала войдите в аккаунт.',
            'unavailable' => 'Не удалось выполнить действие. Проверьте настройки или обратитесь в поддержку.',
            'order_success' => 'Заказ принят.', 'topup_bot' => 'Пополните баланс через бота',
            'language' => 'Язык', 'no_services' => 'Активные услуги не найдены.', 'search' => 'Поиск услуги',
            'google_error' => 'Не удалось подтвердить Google. Попробуйте ещё раз.',
            'telegram_error' => 'Не удалось подтвердить Telegram. Настройте домен бота через BotFather.',
            'captcha_error' => 'Проверка CAPTCHA не пройдена. Попробуйте ещё раз.',
            'signout' => 'Выйти из аккаунта', 'logged_out' => 'Вы вышли из аккаунта.',
        ],
        'en' => [
            'home' => 'Home', 'services' => 'Services', 'api' => 'API', 'bot' => 'Telegram bot',
            'login' => 'Sign in', 'account' => 'Account', 'orders' => 'Orders', 'admin' => 'Admin panel',
            'support' => 'Support', 'logout' => 'Sign out', 'login_title' => 'One account. Website and bot together.',
            'login_desc' => 'Manage the Telegram bot balance, API key, and orders from the website.',
            'telegram_login' => 'Continue with Telegram', 'google_login' => 'Continue with Google',
            'captcha_setup' => 'Configure Google Client ID and Cloudflare Turnstile keys in .env first.',
            'linked' => 'Telegram account connected', 'not_linked' => 'This account is not connected to the Telegram bot yet.',
            'balance' => 'Balance', 'api_key' => 'API key', 'copy' => 'Copy', 'service' => 'Service',
            'link' => 'Link', 'quantity' => 'Quantity', 'place_order' => 'Place order',
            'min' => 'Min', 'max' => 'Max', 'price' => 'Price', 'status' => 'Status',
            'date' => 'Date', 'order_id' => 'Order ID', 'no_orders' => 'No orders yet.',
            'connect_google' => 'Connect Google', 'connect_telegram' => 'Connect Telegram',
            'link_telegram' => 'Connect bot', 'link_help' => 'Press the button and send /start in the opened bot. The code expires in 15 minutes.',
            'analytics' => 'System analytics', 'users' => 'Users', 'total_orders' => 'Orders',
            'pending' => 'In progress', 'revenue' => 'Order value', 'recent_events' => 'Recent events',
            'recent_orders' => 'Recent orders', 'status_online' => 'One database • website and bot connected',
            'support_title' => 'Contact support', 'support_message' => 'Your message', 'send' => 'Send',
            'support_sent' => 'Your message was sent to the administrator.', 'login_required' => 'Sign in first.',
            'unavailable' => 'This action could not be completed. Check configuration or contact support.',
            'order_success' => 'Order accepted.', 'topup_bot' => 'Add funds through the bot',
            'language' => 'Language', 'no_services' => 'No active services found.', 'search' => 'Search services',
            'google_error' => 'Google sign-in could not be verified. Please try again.',
            'telegram_error' => 'Telegram sign-in could not be verified. Set the bot domain in BotFather.',
            'captcha_error' => 'CAPTCHA verification failed. Please try again.',
            'signout' => 'Sign out', 'logged_out' => 'You have signed out.',
        ],
    ];
    return isset($text[$siteLanguage][$key]) ? $text[$siteLanguage][$key] : $key;
}

function funyapi_site_escape_html($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function funyapi_site_json($status, $payload)
{
    if (ob_get_length()) {
        ob_clean();
    }
    http_response_code((int) $status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function funyapi_site_request_json()
{
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    if (is_array($json)) {
        return $json;
    }
    return $_POST;
}

function funyapi_site_post_valid($data)
{
    return isset($_SERVER['REQUEST_METHOD'])
        && $_SERVER['REQUEST_METHOD'] === 'POST'
        && funyapi_site_check_origin()
        && funyapi_site_check_csrf(isset($data['csrf']) ? $data['csrf'] : '');
}

function funyapi_site_account_by($connect, $field, $value)
{
    $allowed = ['account_id', 'google_sub', 'email', 'telegram_user_id'];
    if (!in_array($field, $allowed, true)) {
        return null;
    }
    $statement = mysqli_prepare($connect, 'SELECT account_id, google_sub, email, display_name, role, is_active, telegram_user_id, created_at, last_login FROM site_accounts WHERE `' . $field . '` = ? LIMIT 1');
    if (!$statement) {
        return null;
    }
    mysqli_stmt_bind_param($statement, 's', $value);
    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $account = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    return $account;
}

function funyapi_site_set_account_session($accountId)
{
    funyapi_site_start_session();
    session_regenerate_id(true);
    $_SESSION['funyapi_account_id'] = (int) $accountId;
    $_SESSION['funyapi_csrf'] = bin2hex(random_bytes(32));
}

function funyapi_site_current_bot_user($connect, $account)
{
    if (!$account || empty($account['telegram_user_id'])) {
        return null;
    }
    $statement = mysqli_prepare($connect, 'SELECT user_id, id, balance, outing, api_key, api_status, refnum, status, ban FROM users WHERE id = ? LIMIT 1');
    if (!$statement) {
        return null;
    }
    $telegramId = (string) $account['telegram_user_id'];
    mysqli_stmt_bind_param($statement, 's', $telegramId);
    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    return $user;
}

function funyapi_site_recent_orders($connect, $telegramId, $limit = 15)
{
    $limit = max(1, min(50, (int) $limit));
    $telegramId = mysqli_real_escape_string($connect, (string) $telegramId);
    $query = mysqli_query($connect, "SELECT m.order_id, m.retail, m.status, m.service, m.order_create, s.service_name FROM myorder m LEFT JOIN services s ON s.service_id = m.service WHERE m.user_id = '$telegramId' ORDER BY m.order_id DESC LIMIT $limit");
    $rows = [];
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $rows[] = $row;
        }
    }
    return $rows;
}

function funyapi_site_track($connect, $account, $type, $detail, $notify = false)
{
    funyapi_site_log_event($connect, $type, $detail, $account ? (int) $account['account_id'] : null, $notify);
}

function funyapi_site_provider_add($provider, $serviceId, $link, $quantity)
{
    $providerUrl = isset($provider['api_url']) ? trim((string) $provider['api_url']) : '';
    $parts = parse_url($providerUrl);
    if (!is_array($parts) || !isset($parts['scheme'], $parts['host']) || strtolower($parts['scheme']) !== 'https' || !function_exists('curl_init')) {
        return ['error' => 'Provider HTTPS connection is unavailable.'];
    }

    $ch = curl_init($providerUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'key' => $provider['api_key'], 'action' => 'add', 'service' => $serviceId,
            'link' => $link, 'quantity' => (int) $quantity
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_FOLLOWLOCATION => false
    ]);
    $response = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($response === false || $status < 200 || $status >= 300) {
        return ['error' => 'Provider request failed.'];
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded) || empty($decoded['order']) || isset($decoded['error'])) {
        return ['error' => isset($decoded['error']) ? substr((string) $decoded['error'], 0, 250) : 'Provider rejected the order.'];
    }
    return ['order' => (string) $decoded['order']];
}

function funyapi_site_header($title, $account = null)
{
    global $siteLanguage;
    $safeTitle = funyapi_site_escape_html($title);
    $brand = funyapi_site_escape_html(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'FunyAPI');
    echo '<!doctype html><html lang="' . funyapi_site_escape_html($siteLanguage) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#080d1b"><title>' . $safeTitle . ' · ' . $brand . '</title><link rel="stylesheet" href="/public/funyapi-ui.css"></head><body class="fy-site"><header class="fy-topbar"><a class="fy-brand" href="/">' . $brand . '<span>LIVE SERVICES</span></a><nav><a href="/">' . funyapi_site_t('home') . '</a><a href="/services">' . funyapi_site_t('services') . '</a><a href="/api">' . funyapi_site_t('api') . '</a><a href="https://t.me/' . rawurlencode(TELEGRAM_BOT_USERNAME) . '">' . funyapi_site_t('bot') . '</a><a href="/support">' . funyapi_site_t('support') . '</a></nav><div class="fy-tools"><a href="?lang=uz">UZ</a><a href="?lang=ru">RU</a><a href="?lang=en">EN</a>';
    if ($account) {
        echo '<a class="fy-nav-cta" href="/account">' . funyapi_site_t('account') . '</a>';
    } else {
        echo '<a class="fy-nav-cta" href="/login">' . funyapi_site_t('login') . '</a>';
    }
    echo '</div></header><main class="fy-shell">';
}

function funyapi_site_footer()
{
    echo '</main><footer class="fy-footer"><span>FunyAPI · ' . funyapi_site_escape_html(funyapi_site_t('status_online')) . '</span><a href="/support">' . funyapi_site_escape_html(funyapi_site_t('support')) . '</a></footer></body></html>';
}

function funyapi_site_login_page($message = '')
{
    global $siteLanguage;
    $csrf = funyapi_site_csrf_token();
    $account = funyapi_site_current_account($GLOBALS['connect']);
    funyapi_site_header(funyapi_site_t('login'), $account);
    $messageHtml = $message !== '' ? '<div class="fy-alert">' . funyapi_site_escape_html($message) . '</div>' : '';
    echo '<section class="fy-login-grid"><div class="fy-login-copy"><span class="fy-eyebrow">FUNYAPI · ACCOUNT CENTER</span><h1>' . funyapi_site_escape_html(funyapi_site_t('login_title')) . '</h1><p>' . funyapi_site_escape_html(funyapi_site_t('login_desc')) . '</p><div class="fy-check-list"><span>✓ ' . funyapi_site_escape_html(funyapi_site_t('balance')) . ' va hisob holati</span><span>✓ API kalit va buyurtmalar</span><span>✓ Bot bilan bir xil xizmatlar va baza</span></div><div class="fy-live-pill"><i></i>' . funyapi_site_escape_html(funyapi_site_t('status_online')) . '</div></div><div class="fy-card fy-login-card"><div class="fy-card-icon">✦</div><span class="fy-eyebrow">SECURE SIGN IN</span><h2>' . funyapi_site_escape_html(funyapi_site_t('login')) . '</h2><p class="fy-muted">Google yoki rasmiy Telegram kirishidan foydalaning.</p>' . $messageHtml;
    if (GOOGLE_CLIENT_ID === '' || TURNSTILE_SITE_KEY === '' || TURNSTILE_SECRET_KEY === '') {
        echo '<div class="fy-setup-note">' . funyapi_site_escape_html(funyapi_site_t('captcha_setup')) . '</div>';
    }
    echo '<div id="turnstile-container" class="fy-captcha"></div><div id="telegram-login" class="fy-provider-button"></div><div id="google-login" class="fy-provider-button fy-google"></div><div id="auth-status" class="fy-muted fy-status" aria-live="polite"></div><small>Google va Telegram tokenlari serverda tekshiriladi. Sizning parolingiz saytda saqlanmaydi.</small></div></section>';
    echo '<script>window.FUNYAPI_AUTH={csrf:' . json_encode($csrf) . ',googleClient:' . json_encode(GOOGLE_CLIENT_ID) . ',turnstileSite:' . json_encode(TURNSTILE_SITE_KEY) . ',bot:' . json_encode(TELEGRAM_BOT_USERNAME) . ',lang:' . json_encode($siteLanguage) . '};</script>';
    if (GOOGLE_CLIENT_ID !== '') {
        echo '<script src="https://accounts.google.com/gsi/client" async defer></script>';
    }
    if (TURNSTILE_SITE_KEY !== '') {
        echo '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" async defer></script>';
    }
    echo '<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-login="' . funyapi_site_escape_html(TELEGRAM_BOT_USERNAME) . '" data-size="large" data-userpic="false" data-request-access="write" data-onauth="onFunyapiTelegramAuth(user)"></script>';
    echo '<script>
    (function(){var cfg=window.FUNYAPI_AUTH, captchaId=null, captchaToken="", status=document.getElementById("auth-status");
    function ready(){if(cfg.turnstileSite && window.turnstile && !captchaId){captchaId=window.turnstile.render("#turnstile-container",{sitekey:cfg.turnstileSite,theme:"dark",callback:function(t){captchaToken=t;},"expired-callback":function(){captchaToken="";}});}}
    var timer=setInterval(function(){ready();if(captchaId!==null)clearInterval(timer);},250);
    function submit(path,payload){if(!captchaToken){status.textContent=' . json_encode(funyapi_site_t('captcha_error')) . ';return;}status.textContent="Tekshirilmoqda…";payload.csrf=cfg.csrf;payload.turnstile=captchaToken;fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify(payload)}).then(function(r){return r.json();}).then(function(d){if(d.ok){window.location.href=d.redirect||"/account";}else{status.textContent=d.error||"Kirish amalga oshmadi.";if(window.turnstile&&captchaId!==null)window.turnstile.reset(captchaId);captchaToken="";}}).catch(function(){status.textContent="Aloqa xatosi. Qayta urinib ko‘ring.";});}
    window.onFunyapiTelegramAuth=function(user){submit("/auth/telegram",{telegram:user});};
    window.onFunyapiGoogleAuth=function(response){submit("/auth/google",{credential:response.credential});};
    var googleWait=setInterval(function(){if(window.google&&google.accounts&&google.accounts.id){clearInterval(googleWait);google.accounts.id.initialize({client_id:cfg.googleClient,callback:window.onFunyapiGoogleAuth});google.accounts.id.renderButton(document.getElementById("google-login"),{theme:"filled_black",size:"large",shape:"pill",text:"continue_with",width:300});}},300);
    })();</script>';
    funyapi_site_footer();
}

function funyapi_site_auth_google($connect)
{
    $data = funyapi_site_request_json();
    if (!funyapi_site_post_valid($data)) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'CSRF check failed.']);
    }
    if (!funyapi_site_verify_turnstile(isset($data['turnstile']) ? $data['turnstile'] : '')) {
        funyapi_site_json(400, ['ok' => false, 'error' => funyapi_site_t('captcha_error')]);
    }
    $identity = funyapi_site_verify_google_credential(isset($data['credential']) ? $data['credential'] : '');
    if (!$identity) {
        funyapi_site_track($connect, null, 'auth_failed', 'Google sign-in verification failed');
        funyapi_site_json(401, ['ok' => false, 'error' => funyapi_site_t('google_error')]);
    }

    $account = funyapi_site_account_by($connect, 'google_sub', $identity['google_sub']);
    $current = funyapi_site_current_account($connect);
    if ($current && !empty($current['telegram_user_id'])) {
        if ($account && (int) $account['account_id'] !== (int) $current['account_id']) {
            funyapi_site_json(409, ['ok' => false, 'error' => 'Google hisobi boshqa FunyAPI hisobiga biriktirilgan.']);
        }
        $email = $identity['email'];
        $name = $identity['display_name'];
        $statement = mysqli_prepare($connect, 'UPDATE site_accounts SET google_sub = ?, email = ?, display_name = ? WHERE account_id = ? AND (google_sub IS NULL OR google_sub = ?)');
        mysqli_stmt_bind_param($statement, 'sssis', $identity['google_sub'], $email, $name, $current['account_id'], $identity['google_sub']);
        $ok = mysqli_stmt_execute($statement);
        mysqli_stmt_close($statement);
        if (!$ok) {
            funyapi_site_json(409, ['ok' => false, 'error' => 'Google hisobi boshqa hisobga biriktirilgan.']);
        }
        $account = funyapi_site_account_by($connect, 'account_id', (string) $current['account_id']);
        funyapi_site_track($connect, $account, 'google_linked', 'Google account linked to Telegram identity');
    } elseif (!$account) {
        $email = $identity['email'];
        $name = $identity['display_name'];
        $created = date('Y-m-d H:i:s');
        $statement = mysqli_prepare($connect, 'INSERT INTO site_accounts (google_sub, email, display_name, created_at, last_login) VALUES (?, ?, ?, ?, ?)');
        if (!$statement) {
            funyapi_site_json(500, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
        }
        mysqli_stmt_bind_param($statement, 'sssss', $identity['google_sub'], $email, $name, $created, $created);
        $ok = mysqli_stmt_execute($statement);
        $newId = (int) mysqli_insert_id($connect);
        mysqli_stmt_close($statement);
        if (!$ok || $newId < 1) {
            funyapi_site_json(500, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
        }
        $account = funyapi_site_account_by($connect, 'account_id', (string) $newId);
        funyapi_site_track($connect, $account, 'google_registered', 'Google account created');
    }

    if (!$account || (int) $account['is_active'] !== 1) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'Hisob faol emas.']);
    }
    $updated = mysqli_prepare($connect, 'UPDATE site_accounts SET last_login = ? WHERE account_id = ?');
    $now = date('Y-m-d H:i:s');
    mysqli_stmt_bind_param($updated, 'si', $now, $account['account_id']);
    mysqli_stmt_execute($updated);
    mysqli_stmt_close($updated);
    funyapi_site_track($connect, $account, 'google_login', 'Google sign-in succeeded');
    funyapi_site_set_account_session($account['account_id']);
    funyapi_site_json(200, ['ok' => true, 'redirect' => '/account']);
}

function funyapi_site_auth_telegram($connect)
{
    $data = funyapi_site_request_json();
    if (!funyapi_site_post_valid($data)) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'CSRF check failed.']);
    }
    if (!funyapi_site_verify_turnstile(isset($data['turnstile']) ? $data['turnstile'] : '')) {
        funyapi_site_json(400, ['ok' => false, 'error' => funyapi_site_t('captcha_error')]);
    }
    $telegram = isset($data['telegram']) && is_array($data['telegram']) ? $data['telegram'] : [];
    $providedHash = isset($telegram['hash']) ? strtolower((string) $telegram['hash']) : '';
    $authDate = isset($telegram['auth_date']) ? (int) $telegram['auth_date'] : 0;
    $telegramId = isset($telegram['id']) ? (string) $telegram['id'] : '';
    if (API_KEY === '' || !preg_match('/^[1-9][0-9]{0,19}$/', $telegramId) || !preg_match('/^[a-f0-9]{64}$/', $providedHash) || $authDate < time() - 600 || $authDate > time() + 60) {
        funyapi_site_track($connect, null, 'auth_failed', 'Telegram login payload rejected');
        funyapi_site_json(401, ['ok' => false, 'error' => funyapi_site_t('telegram_error')]);
    }
    $fields = [];
    foreach ($telegram as $key => $value) {
        if ($key !== 'hash' && (is_string($value) || is_numeric($value))) {
            $fields[$key] = (string) $value;
        }
    }
    ksort($fields, SORT_STRING);
    $checkString = [];
    foreach ($fields as $key => $value) {
        $checkString[] = $key . '=' . $value;
    }
    $secretKey = hash('sha256', API_KEY, true);
    $expectedHash = hash_hmac('sha256', implode("\n", $checkString), $secretKey);
    if (!hash_equals($expectedHash, $providedHash)) {
        funyapi_site_track($connect, null, 'auth_failed', 'Telegram signature mismatch');
        funyapi_site_json(401, ['ok' => false, 'error' => funyapi_site_t('telegram_error')]);
    }
    if (!funyapi_ensure_bot_user($connect, $telegramId)) {
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }

    $account = funyapi_site_account_by($connect, 'telegram_user_id', $telegramId);
    if (!$account) {
        $name = trim((isset($telegram['first_name']) ? $telegram['first_name'] : '') . ' ' . (isset($telegram['last_name']) ? $telegram['last_name'] : ''));
        $name = substr($name !== '' ? $name : (isset($telegram['username']) ? $telegram['username'] : 'Telegram user'), 0, 200);
        $created = date('Y-m-d H:i:s');
        $statement = mysqli_prepare($connect, 'INSERT IGNORE INTO site_accounts (display_name, role, is_active, telegram_user_id, created_at, last_login) VALUES (?, \'user\', 1, ?, ?, ?)');
        if ($statement) {
            mysqli_stmt_bind_param($statement, 'ssss', $name, $telegramId, $created, $created);
            mysqli_stmt_execute($statement);
            mysqli_stmt_close($statement);
        }
        $account = funyapi_site_account_by($connect, 'telegram_user_id', $telegramId);
        if (!$account) {
            funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
        }
        funyapi_site_track($connect, $account, 'telegram_registered', 'Telegram account created');
    } elseif ((int) $account['is_active'] !== 1) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'Hisob faol emas.']);
    }
    $updated = mysqli_prepare($connect, 'UPDATE site_accounts SET last_login = ? WHERE account_id = ?');
    $now = date('Y-m-d H:i:s');
    mysqli_stmt_bind_param($updated, 'si', $now, $account['account_id']);
    mysqli_stmt_execute($updated);
    mysqli_stmt_close($updated);
    funyapi_site_track($connect, $account, 'telegram_login', 'Telegram sign-in succeeded');
    funyapi_site_set_account_session($account['account_id']);
    funyapi_site_json(200, ['ok' => true, 'redirect' => '/account']);
}

function funyapi_site_create_link_code($connect, $account)
{
    if (!$account || !empty($account['telegram_user_id'])) {
        return null;
    }
    $code = bin2hex(random_bytes(24));
    $hash = hash('sha256', $code);
    $expires = date('Y-m-d H:i:s', time() + 900);
    $statement = mysqli_prepare($connect, 'UPDATE site_accounts SET link_code_hash = ?, link_expires_at = ? WHERE account_id = ? AND telegram_user_id IS NULL');
    if (!$statement) {
        return null;
    }
    mysqli_stmt_bind_param($statement, 'ssi', $hash, $expires, $account['account_id']);
    $ok = mysqli_stmt_execute($statement) && mysqli_stmt_affected_rows($statement) > 0;
    mysqli_stmt_close($statement);
    return $ok ? $code : null;
}

function funyapi_site_checkout($connect, $account)
{
    $data = funyapi_site_request_json();
    if (!funyapi_site_post_valid($data)) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'CSRF check failed.']);
    }
    if (!$account || empty($account['telegram_user_id'])) {
        funyapi_site_json(403, ['ok' => false, 'error' => 'Telegram hisobini avval ulang.']);
    }
    $telegramId = (string) $account['telegram_user_id'];
    $serviceId = isset($data['service_id']) ? (int) $data['service_id'] : 0;
    $quantity = isset($data['quantity']) ? filter_var($data['quantity'], FILTER_VALIDATE_INT) : false;
    $link = trim(isset($data['link']) ? (string) $data['link'] : '');
    if ($serviceId < 1 || $quantity === false || $quantity < 1 || strlen($link) > 2048 || filter_var($link, FILTER_VALIDATE_URL) === false || !in_array(strtolower((string) parse_url($link, PHP_URL_SCHEME)), ['https', 'http'], true)) {
        funyapi_site_json(422, ['ok' => false, 'error' => 'Xizmat, havola va miqdorni to‘g‘ri kiriting.']);
    }

    $statement = mysqli_prepare($connect, "SELECT service_id, service_api, api_service, service_price, service_type, service_min, service_max, service_name FROM services WHERE service_id = ? AND service_status = 'on' LIMIT 1");
    if (!$statement) {
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }
    mysqli_stmt_bind_param($statement, 'i', $serviceId);
    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $service = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($statement);
    if (!$service) {
        funyapi_site_json(404, ['ok' => false, 'error' => 'Xizmat topilmadi yoki faol emas.']);
    }

    $serviceType = strtolower(trim((string) $service['service_type']));
    $minimum = (int) $service['service_min'];
    $maximum = (int) $service['service_max'];
    if ($serviceType !== 'package' && ($quantity < $minimum || $quantity > $maximum)) {
        funyapi_site_json(422, ['ok' => false, 'error' => 'Miqdor ' . $minimum . ' dan ' . $maximum . ' gacha bo‘lishi kerak.']);
    }
    if ($serviceType === 'package') {
        $quantity = 1;
    }
    // Keep website pricing identical to the Telegram bot (two decimal places).
    $price = $serviceType === 'package'
        ? round((float) $service['service_price'], 2)
        : round(((float) $service['service_price'] / 1000) * (int) $quantity, 2);
    if (!is_finite($price) || $price <= 0) {
        funyapi_site_json(422, ['ok' => false, 'error' => 'Xizmat narxi sozlanmagan.']);
    }

    $providerId = (int) $service['api_service'];
    $providerStatement = mysqli_prepare($connect, 'SELECT id, api_url, api_key FROM providers WHERE id = ? LIMIT 1');
    if (!$providerStatement) {
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }
    mysqli_stmt_bind_param($providerStatement, 'i', $providerId);
    mysqli_stmt_execute($providerStatement);
    $providerResult = mysqli_stmt_get_result($providerStatement);
    $provider = $providerResult ? mysqli_fetch_assoc($providerResult) : null;
    mysqli_stmt_close($providerStatement);
    $providerUrl = $provider ? parse_url(trim((string) $provider['api_url'])) : false;
    if (!$provider || !is_array($providerUrl) || !isset($providerUrl['scheme'], $providerUrl['host']) || strtolower($providerUrl['scheme']) !== 'https' || !function_exists('curl_init')) {
        funyapi_site_json(503, ['ok' => false, 'error' => 'Xizmat provayderi hozircha ulanmagan.']);
    }

    if (!mysqli_begin_transaction($connect)) {
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }
    $lock = mysqli_prepare($connect, 'SELECT balance, status, ban FROM users WHERE id = ? FOR UPDATE');
    if (!$lock) {
        mysqli_rollback($connect);
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }
    mysqli_stmt_bind_param($lock, 's', $telegramId);
    mysqli_stmt_execute($lock);
    $userResult = mysqli_stmt_get_result($lock);
    $user = $userResult ? mysqli_fetch_assoc($userResult) : null;
    mysqli_stmt_close($lock);
    if (!$user || $user['status'] !== 'active' || (int) $user['ban'] === 1 || (float) $user['balance'] < $price) {
        mysqli_rollback($connect);
        funyapi_site_json(422, ['ok' => false, 'error' => 'Balans yetarli emas yoki hisob faol emas. ' . funyapi_site_t('topup_bot') . '.']);
    }

    $retail = number_format($price, 2, '.', '');
    $debit = mysqli_prepare($connect, 'UPDATE users SET balance = CAST(balance AS DECIMAL(20,2)) - ? WHERE id = ?');
    $debitOk = false;
    if ($debit) {
        mysqli_stmt_bind_param($debit, 'ds', $price, $telegramId);
        $debitOk = mysqli_stmt_execute($debit);
        mysqli_stmt_close($debit);
    }
    $allocated = $debitOk ? mysqli_query($connect, 'UPDATE settings SET ordercount = LAST_INSERT_ID(GREATEST(ordercount, COALESCE((SELECT MAX(order_id) FROM myorder), 0)) + 1) WHERE id = 1') : false;
    $orderId = $allocated ? (int) mysqli_insert_id($connect) : 0;
    $created = date('Y.m.d H:i:s');
    $serviceValue = (string) $serviceId;
    $saved = false;

    if ($orderId > 0) {
        $m = mysqli_prepare($connect, "INSERT INTO myorder (order_id, user_id, retail, status, service, order_create, last_check) VALUES (?, ?, ?, 'Processing', ?, ?, ?)");
        $o = mysqli_prepare($connect, "INSERT INTO orders (order_id, api_order, provider, status) VALUES (?, '', ?, 'Processing')");
        $n = mysqli_prepare($connect, "INSERT INTO neworder (order_id, api_order_id, provider, user_id, retail, status, service, order_create, last_check) VALUES (?, '', ?, ?, ?, 'Processing', ?, ?, ?)");
        if ($m && $o && $n) {
            mysqli_stmt_bind_param($m, 'ississ', $orderId, $telegramId, $retail, $serviceValue, $created, $created);
            mysqli_stmt_bind_param($o, 'ii', $orderId, $providerId);
            mysqli_stmt_bind_param($n, 'iisssss', $orderId, $providerId, $telegramId, $retail, $serviceValue, $created, $created);
            $saved = mysqli_stmt_execute($m) && mysqli_stmt_execute($o) && mysqli_stmt_execute($n);
        }
        if ($m) mysqli_stmt_close($m);
        if ($o) mysqli_stmt_close($o);
        if ($n) mysqli_stmt_close($n);
    }

    if (!$debitOk || !$saved) {
        mysqli_rollback($connect);
        error_log('FunyAPI could not reserve balance and create a local web order for Telegram user ' . $telegramId . '.');
        funyapi_site_json(503, ['ok' => false, 'error' => funyapi_site_t('unavailable')]);
    }
    if (!mysqli_commit($connect)) {
        mysqli_rollback($connect);
        error_log('FunyAPI could not confirm the local web-order reservation for order #' . $orderId . '.');
        funyapi_site_json(503, ['ok' => false, 'error' => 'Buyurtma holatini tekshirib, birozdan so‘ng qayta urinib ko‘ring.']);
    }

    // A traceable Processing order exists before contacting the provider. This prevents
    // successful remote orders from becoming invisible if local persistence later fails.
    $remote = funyapi_site_provider_add($provider, $service['service_api'], $link, $quantity);
    if (empty($remote['order'])) {
        $refunded = false;
        if (mysqli_begin_transaction($connect)) {
            $refund = mysqli_prepare($connect, 'UPDATE users SET balance = CAST(balance AS DECIMAL(20,2)) + ? WHERE id = ?');
            $cancelMy = mysqli_prepare($connect, "UPDATE myorder SET status = 'Canceled', last_check = ? WHERE order_id = ? AND user_id = ?");
            $cancelOrder = mysqli_prepare($connect, "UPDATE orders SET status = 'Canceled' WHERE order_id = ?");
            $cancelNew = mysqli_prepare($connect, "UPDATE neworder SET status = 'Canceled', last_check = ? WHERE order_id = ?");
            if ($refund && $cancelMy && $cancelOrder && $cancelNew) {
                mysqli_stmt_bind_param($refund, 'ds', $price, $telegramId);
                mysqli_stmt_bind_param($cancelMy, 'sis', $created, $orderId, $telegramId);
                mysqli_stmt_bind_param($cancelOrder, 'i', $orderId);
                mysqli_stmt_bind_param($cancelNew, 'si', $created, $orderId);
                $refunded = mysqli_stmt_execute($refund) && mysqli_stmt_execute($cancelMy) && mysqli_stmt_execute($cancelOrder) && mysqli_stmt_execute($cancelNew);
            }
            if ($refund) mysqli_stmt_close($refund);
            if ($cancelMy) mysqli_stmt_close($cancelMy);
            if ($cancelOrder) mysqli_stmt_close($cancelOrder);
            if ($cancelNew) mysqli_stmt_close($cancelNew);
            if ($refunded) {
                $refunded = mysqli_commit($connect);
            } else {
                mysqli_rollback($connect);
            }
        }
        if (!$refunded) {
            error_log('FunyAPI failed to cancel/refund rejected web order #' . $orderId . '.');
            funyapi_site_track($connect, $account, 'order_refund_failed', 'Manual review required for order #' . $orderId, true);
            funyapi_site_json(500, ['ok' => false, 'error' => 'Buyurtma holati tekshirilmoqda. Yordam xizmatiga order #' . $orderId . ' bilan murojaat qiling.']);
        }
        funyapi_site_track($connect, $account, 'order_failed', 'Provider rejected web order #' . $orderId);
        funyapi_site_json(502, ['ok' => false, 'error' => 'Provayder buyurtmani qabul qilmadi. Mablag‘ qaytarildi.']);
    }

    $externalOrder = (string) $remote['order'];
    $updated = false;
    if (mysqli_begin_transaction($connect)) {
        $updateMy = mysqli_prepare($connect, "UPDATE myorder SET status = 'Pending', last_check = ? WHERE order_id = ? AND user_id = ?");
        $updateOrder = mysqli_prepare($connect, "UPDATE orders SET api_order = ?, status = 'Pending' WHERE order_id = ?");
        $updateNew = mysqli_prepare($connect, "UPDATE neworder SET api_order_id = ?, status = 'Pending', last_check = ? WHERE order_id = ?");
        if ($updateMy && $updateOrder && $updateNew) {
            mysqli_stmt_bind_param($updateMy, 'sis', $created, $orderId, $telegramId);
            mysqli_stmt_bind_param($updateOrder, 'si', $externalOrder, $orderId);
            mysqli_stmt_bind_param($updateNew, 'ssi', $externalOrder, $created, $orderId);
            $updated = mysqli_stmt_execute($updateMy) && mysqli_stmt_execute($updateOrder) && mysqli_stmt_execute($updateNew);
        }
        if ($updateMy) mysqli_stmt_close($updateMy);
        if ($updateOrder) mysqli_stmt_close($updateOrder);
        if ($updateNew) mysqli_stmt_close($updateNew);
        if ($updated) {
            $updated = mysqli_commit($connect);
        } else {
            mysqli_rollback($connect);
        }
    }
    if (!$updated) {
        // The remote order is accepted and must not be refunded; the local Processing
        // row remains available for admin reconciliation without creating a duplicate.
        error_log('FunyAPI provider accepted web order #' . $orderId . ', but tracking update failed.');
        funyapi_site_track($connect, $account, 'order_tracking_delayed', 'Provider accepted order #' . $orderId . '; reconciliation required', true);
        funyapi_site_json(200, ['ok' => true, 'order' => $orderId, 'message' => 'Buyurtma qabul qilindi. Holati yangilanmoqda.']);
    }
    funyapi_site_track($connect, $account, 'web_order_created', 'Order #' . $orderId . ' · service ' . $serviceId . ' · ' . $retail . ' UZS', true);
    funyapi_site_json(200, ['ok' => true, 'order' => $orderId, 'message' => funyapi_site_t('order_success')]);
}

if ($siteRoute === 'auth' && isset($route[1]) && $route[1] === 'google') {
    funyapi_site_auth_google($connect);
}
if ($siteRoute === 'auth' && isset($route[1]) && $route[1] === 'telegram') {
    funyapi_site_auth_telegram($connect);
}
if ($siteRoute === 'checkout') {
    funyapi_site_checkout($connect, funyapi_site_current_account($connect));
}

$siteAccount = funyapi_site_current_account($connect);

if ($siteRoute === 'login') {
    if ($siteAccount) {
        header('Location: /account');
        exit;
    }
    funyapi_site_login_page(isset($_GET['error']) ? funyapi_site_t((string) $_GET['error']) : '');
    exit;
}

if ($siteRoute === 'logout') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = funyapi_site_request_json();
        if (funyapi_site_post_valid($data)) {
            $_SESSION = [];
            session_regenerate_id(true);
            $_SESSION['funyapi_csrf'] = bin2hex(random_bytes(32));
            header('Location: /login');
            exit;
        }
    }
    header('Location: /account');
    exit;
}

if ($siteRoute === 'support' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = funyapi_site_request_json();
    $siteSupportOk = false;
    if (!funyapi_site_post_valid($data)) {
        http_response_code(403);
        $siteMessage = 'CSRF tekshiruvi amalga oshmadi.';
    } elseif (!funyapi_site_verify_turnstile(isset($data['turnstile']) ? $data['turnstile'] : '')) {
        $siteMessage = funyapi_site_t('captcha_error');
    } else {
        $message = trim(isset($data['message']) ? (string) $data['message'] : '');
        if ($message === '' || strlen($message) > 2000) {
            $siteMessage = 'Xabar 1–2000 belgi bo‘lishi kerak.';
        } else {
            $who = $siteAccount ? (string) $siteAccount['display_name'] : 'Mehmon';
            $detail = substr($who . ' · ' . $message, 0, 1000);
            funyapi_site_track($connect, $siteAccount, 'support_message', $detail, true);
            $siteMessage = funyapi_site_t('support_sent');
            $siteSupportOk = true;
        }
    }
    funyapi_site_json($siteSupportOk ? 200 : (http_response_code() >= 400 ? http_response_code() : 422), ['ok' => $siteSupportOk, 'message' => $siteSupportOk ? $siteMessage : null, 'error' => $siteSupportOk ? null : $siteMessage]);
}

if ($siteRoute === 'account' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = funyapi_site_request_json();
    if (!funyapi_site_post_valid($data)) {
        http_response_code(403);
        $siteMessage = 'CSRF tekshiruvi amalga oshmadi.';
    } else {
        $siteAccount = funyapi_site_require_account($connect);
        $linkCode = funyapi_site_create_link_code($connect, $siteAccount);
        if ($linkCode) {
            $siteMessage = 'Telegram botga ulash uchun yangi havola tayyor.';
            $GLOBALS['funyapiLinkUrl'] = 'https://t.me/' . rawurlencode(TELEGRAM_BOT_USERNAME) . '?start=link_' . rawurlencode($linkCode);
            funyapi_site_track($connect, $siteAccount, 'telegram_link_started', 'Telegram link code requested');
        }
    }
}

if ($siteRoute === 'support') {
    $csrf = funyapi_site_csrf_token();
    funyapi_site_header(funyapi_site_t('support_title'), $siteAccount);
    echo '<section class="fy-section-head"><span class="fy-eyebrow">HELP DESK</span><h1>' . funyapi_site_escape_html(funyapi_site_t('support_title')) . '</h1><p>Telegram bot orqali ham murojaat yuborishingiz mumkin.</p></section><section class="fy-card fy-support-card">';
    if (!empty($siteMessage)) echo '<div class="fy-alert">' . funyapi_site_escape_html($siteMessage) . '</div>';
    echo '<label for="support-message">' . funyapi_site_escape_html(funyapi_site_t('support_message')) . '</label><textarea id="support-message" rows="6" maxlength="2000" placeholder="Savolingizni yozing"></textarea><div id="support-turnstile" class="fy-captcha"></div><button id="support-send" class="fy-button" type="button">' . funyapi_site_escape_html(funyapi_site_t('send')) . '</button><div id="support-status" class="fy-muted" aria-live="polite"></div></section><script>window.FUNYAPI_SUPPORT=' . json_encode(['csrf' => $csrf, 'sitekey' => TURNSTILE_SITE_KEY]) . ';(function(){var cfg=window.FUNYAPI_SUPPORT,id=null,token="",status=document.getElementById("support-status"),button=document.getElementById("support-send");var timer=setInterval(function(){if(window.turnstile&&cfg.sitekey&&id===null){id=turnstile.render("#support-turnstile",{sitekey:cfg.sitekey,theme:"dark",callback:function(t){token=t;}});clearInterval(timer);}},250);button.onclick=function(){button.disabled=true;fetch("/support",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify({csrf:cfg.csrf,turnstile:token,message:document.getElementById("support-message").value})}).then(function(r){return r.json();}).then(function(d){status.textContent=d.ok?d.message:(d.error||"Yuborilmadi. Qayta urinib ko‘ring.");if(d.ok)document.getElementById("support-message").value="";if(window.turnstile&&id!==null)turnstile.reset(id);token="";}).catch(function(){status.textContent="Yuborilmadi. Qayta urinib ko‘ring.";}).finally(function(){button.disabled=false;});};})();</script>';
    funyapi_site_footer();
    exit;
}

if (!$siteAccount && in_array($siteRoute, ['account', 'my-orders', 'admin'], true)) {
    header('Location: /login');
    exit;
}

if ($siteRoute === 'admin') {
    $siteAccount = funyapi_site_require_admin($connect);
    $userCount = mysqli_fetch_assoc(mysqli_query($connect, 'SELECT COUNT(*) AS n FROM users'));
    $orderStats = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) AS n, COALESCE(SUM(CASE WHEN status <> 'Canceled' THEN CAST(retail AS DECIMAL(20,2)) ELSE 0 END),0) AS total, COALESCE(SUM(status IN ('Pending','In progress','Processing')),0) AS pending FROM myorder"));
    $newAccounts = mysqli_fetch_assoc(mysqli_query($connect, 'SELECT COUNT(*) AS n FROM site_accounts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)'));
    $events = mysqli_query($connect, 'SELECT event_type, detail, created_at FROM site_events ORDER BY event_id DESC LIMIT 20');
    $orders = mysqli_query($connect, 'SELECT m.order_id, m.user_id, m.retail, m.status, m.order_create, s.service_name FROM myorder m LEFT JOIN services s ON s.service_id = m.service ORDER BY m.order_id DESC LIMIT 20');
    $servicesCount = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) AS n FROM services WHERE service_status = 'on'"));
    $dailyOrders = [];
    $chartStart = date('Y-m-d', strtotime('-6 days'));
    $chartQuery = mysqli_query($connect, "SELECT DATE(STR_TO_DATE(order_create, '%Y.%m.%d %H:%i:%s')) AS order_day, COUNT(*) AS total FROM myorder WHERE STR_TO_DATE(order_create, '%Y.%m.%d %H:%i:%s') >= CURDATE() - INTERVAL 6 DAY GROUP BY order_day");
    if ($chartQuery) {
        while ($chartRow = mysqli_fetch_assoc($chartQuery)) $dailyOrders[$chartRow['order_day']] = (int) $chartRow['total'];
    }
    $chartValues = [];
    for ($dayOffset = 6; $dayOffset >= 0; $dayOffset--) {
        $chartDate = date('Y-m-d', strtotime('-' . $dayOffset . ' days'));
        $chartValues[] = ['date' => $chartDate, 'label' => date('D', strtotime($chartDate)), 'count' => isset($dailyOrders[$chartDate]) ? $dailyOrders[$chartDate] : 0];
    }
    $chartMax = max(1, max(array_column($chartValues, 'count')));
    funyapi_site_header(funyapi_site_t('admin'), $siteAccount);
    echo '<section class="fy-section-head"><span class="fy-eyebrow">ADMIN · LIVE DATA</span><h1>' . funyapi_site_escape_html(funyapi_site_t('analytics')) . '</h1><p>Ko‘rsatkichlar aynan Telegram bot ishlatadigan bazadan olinadi.</p></section><section class="fy-stat-grid"><article class="fy-stat"><span>' . funyapi_site_escape_html(funyapi_site_t('users')) . '</span><strong>' . (int) $userCount['n'] . '</strong><small>7 kunda yangi: ' . (int) $newAccounts['n'] . '</small></article><article class="fy-stat"><span>' . funyapi_site_escape_html(funyapi_site_t('total_orders')) . '</span><strong>' . (int) $orderStats['n'] . '</strong><small>' . (int) $servicesCount['n'] . ' faol xizmat</small></article><article class="fy-stat"><span>' . funyapi_site_escape_html(funyapi_site_t('pending')) . '</span><strong>' . (int) $orderStats['pending'] . '</strong><small>Bot va sayt buyurtmalari</small></article><article class="fy-stat"><span>' . funyapi_site_escape_html(funyapi_site_t('revenue')) . '</span><strong>' . number_format((float) $orderStats['total'], 0, '.', ' ') . '</strong><small>UZS · tarixiy buyurtmalar</small></article></section><section class="fy-card fy-chart"><div class="fy-card-heading"><div><span class="fy-eyebrow">LAST 7 DAYS · SHARED BOT + WEB</span><h2>Kunlik buyurtmalar</h2></div><strong>' . array_sum(array_column($chartValues, 'count')) . ' <small>7 kun</small></strong></div><div class="fy-bars">';
    foreach ($chartValues as $chartValue) {
        $barHeight = max(5, (int) round(($chartValue['count'] / $chartMax) * 100));
        echo '<div class="fy-bar-col" aria-label="' . funyapi_site_escape_html($chartValue['date'] . ': ' . $chartValue['count']) . '"><strong>' . (int) $chartValue['count'] . '</strong><div class="fy-bar-track"><i style="height:' . $barHeight . '%"></i></div><small>' . funyapi_site_escape_html($chartValue['label']) . '</small></div>';
    }
    echo '</div></section><section class="fy-two-col"><article class="fy-card"><div class="fy-card-heading"><div><span class="fy-eyebrow">AUDIT LOG</span><h2>' . funyapi_site_escape_html(funyapi_site_t('recent_events')) . '</h2></div><span class="fy-live-pill"><i></i>LIVE</span></div><div class="fy-event-list">';
    if ($events) while ($event = mysqli_fetch_assoc($events)) echo '<div class="fy-event"><i></i><div><b>' . funyapi_site_escape_html($event['event_type']) . '</b><p>' . funyapi_site_escape_html($event['detail']) . '</p><small>' . funyapi_site_escape_html($event['created_at']) . '</small></div></div>';
    echo '</div></article><article class="fy-card"><div class="fy-card-heading"><div><span class="fy-eyebrow">OPERATIONS</span><h2>' . funyapi_site_escape_html(funyapi_site_t('recent_orders')) . '</h2></div></div><div class="fy-table-wrap"><table class="fy-table"><thead><tr><th>ID</th><th>Telegram ID</th><th>' . funyapi_site_escape_html(funyapi_site_t('service')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('price')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('status')) . '</th></tr></thead><tbody>';
    if ($orders) while ($order = mysqli_fetch_assoc($orders)) {
        $serviceName = base64_decode((string) $order['service_name'], true);
        if ($serviceName === false) $serviceName = (string) $order['service_name'];
        echo '<tr><td>#' . (int) $order['order_id'] . '</td><td>' . funyapi_site_escape_html($order['user_id']) . '</td><td>' . funyapi_site_escape_html($serviceName) . '</td><td>' . number_format((float) $order['retail'], 0, '.', ' ') . '</td><td><span class="fy-tag">' . funyapi_site_escape_html($order['status']) . '</span></td></tr>';
    }
    echo '</tbody></table></div></article></section>';
    funyapi_site_footer();
    exit;
}

if ($siteRoute === 'my-orders') {
    $siteAccount = funyapi_site_require_account($connect);
    $telegramUser = funyapi_site_current_bot_user($connect, $siteAccount);
    $orders = $telegramUser ? funyapi_site_recent_orders($connect, $siteAccount['telegram_user_id'], 50) : [];
    funyapi_site_header(funyapi_site_t('orders'), $siteAccount);
    echo '<section class="fy-section-head"><span class="fy-eyebrow">ORDER HISTORY</span><h1>' . funyapi_site_escape_html(funyapi_site_t('orders')) . '</h1></section><section class="fy-card"><div class="fy-table-wrap"><table class="fy-table"><thead><tr><th>' . funyapi_site_escape_html(funyapi_site_t('order_id')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('service')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('price')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('status')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('date')) . '</th></tr></thead><tbody>';
    foreach ($orders as $order) {
        $serviceName = base64_decode((string) $order['service_name'], true);
        if ($serviceName === false) $serviceName = (string) $order['service_name'];
        echo '<tr><td>#' . (int) $order['order_id'] . '</td><td>' . funyapi_site_escape_html($serviceName) . '</td><td>' . number_format((float) $order['retail'], 0, '.', ' ') . ' UZS</td><td><span class="fy-tag">' . funyapi_site_escape_html($order['status']) . '</span></td><td>' . funyapi_site_escape_html($order['order_create']) . '</td></tr>';
    }
    if (!$orders) echo '<tr><td colspan="5">' . funyapi_site_escape_html(funyapi_site_t('no_orders')) . '</td></tr>';
    echo '</tbody></table></div></section>';
    funyapi_site_footer();
    exit;
}

if ($siteRoute === 'account') {
    $siteAccount = funyapi_site_require_account($connect);
    $telegramUser = funyapi_site_current_bot_user($connect, $siteAccount);
    $csrf = funyapi_site_csrf_token();
    $orders = $telegramUser ? funyapi_site_recent_orders($connect, $siteAccount['telegram_user_id'], 8) : [];
    funyapi_site_header(funyapi_site_t('account'), $siteAccount);
    echo '<section class="fy-section-head fy-dashboard-head"><div><span class="fy-eyebrow">YOUR FUNYAPI</span><h1>' . funyapi_site_escape_html($siteAccount['display_name']) . '</h1><p>' . funyapi_site_escape_html(funyapi_site_t('status_online')) . '</p></div><div class="fy-head-actions"><a class="fy-button fy-button-ghost" href="/my-orders">' . funyapi_site_escape_html(funyapi_site_t('orders')) . '</a><form method="post" action="/logout"><input type="hidden" name="csrf" value="' . funyapi_site_escape_html($csrf) . '"><button class="fy-button fy-button-ghost">' . funyapi_site_escape_html(funyapi_site_t('signout')) . '</button></form></div></section>';
    if (!empty($siteMessage)) echo '<div class="fy-alert">' . funyapi_site_escape_html($siteMessage) . '</div>';
    echo '<section class="fy-account-grid"><article class="fy-stat fy-balance"><span>' . funyapi_site_escape_html(funyapi_site_t('balance')) . '</span><strong>' . ($telegramUser ? number_format((float) $telegramUser['balance'], 0, '.', ' ') : '—') . '</strong><small>UZS · ' . ($telegramUser ? funyapi_site_escape_html(funyapi_site_t('linked')) : funyapi_site_escape_html(funyapi_site_t('not_linked'))) . '</small></article><article class="fy-card fy-key-card"><div><span class="fy-eyebrow">DEVELOPER ACCESS</span><h2>' . funyapi_site_escape_html(funyapi_site_t('api_key')) . '</h2><p class="fy-muted">API kalit aynan bot hisobingizdan olinadi.</p></div><div class="fy-key-row"><code>' . ($telegramUser ? funyapi_site_escape_html($telegramUser['api_key']) : 'Telegram hisob ulangandan keyin ko‘rinadi') . '</code>' . ($telegramUser ? '<button class="fy-copy" type="button" onclick="navigator.clipboard.writeText(' . json_encode($telegramUser['api_key']) . ').then(()=>this.textContent=\'✓\')">' . funyapi_site_escape_html(funyapi_site_t('copy')) . '</button>' : '') . '</div></article></section>';
    if (empty($siteAccount['telegram_user_id'])) {
        echo '<section class="fy-card fy-connect-card"><div class="fy-connect-symbol">↗</div><div><span class="fy-eyebrow">ONE UNIFIED ACCOUNT</span><h2>' . funyapi_site_escape_html(funyapi_site_t('connect_telegram')) . '</h2><p>' . funyapi_site_escape_html(funyapi_site_t('link_help')) . '</p>';
        if (!empty($GLOBALS['funyapiLinkUrl'])) {
            echo '<a class="fy-button" href="' . funyapi_site_escape_html($GLOBALS['funyapiLinkUrl']) . '">' . funyapi_site_escape_html(funyapi_site_t('link_telegram')) . '</a>';
        } else {
            echo '<form method="post" action="/account"><input type="hidden" name="csrf" value="' . funyapi_site_escape_html($csrf) . '"><button class="fy-button" type="submit">' . funyapi_site_escape_html(funyapi_site_t('link_telegram')) . '</button></form>';
        }
        echo '</div></section>';
    }
    if ($telegramUser) {
        $services = mysqli_query($connect, "SELECT service_id, service_name, service_price, service_type, service_min, service_max FROM services WHERE service_status = 'on' ORDER BY service_id DESC LIMIT 500");
        echo '<section class="fy-card fy-order-card"><div class="fy-card-heading"><div><span class="fy-eyebrow">ORDER CENTER</span><h2>' . funyapi_site_escape_html(funyapi_site_t('place_order')) . '</h2></div><span class="fy-tag">BALANCE ' . number_format((float) $telegramUser['balance'], 0, '.', ' ') . ' UZS</span></div>';
        if (!$services || mysqli_num_rows($services) === 0) {
            echo '<p>' . funyapi_site_escape_html(funyapi_site_t('no_services')) . '</p>';
        } else {
            echo '<form id="fy-checkout-form" class="fy-order-form"><label>' . funyapi_site_escape_html(funyapi_site_t('search')) . '<input id="fy-service-search" type="search" placeholder="Instagram, YouTube, TikTok..."></label><label>' . funyapi_site_escape_html(funyapi_site_t('service')) . '<select id="fy-service" name="service_id" required><option value="">Xizmatni tanlang</option>';
            $serviceMeta = [];
            while ($service = mysqli_fetch_assoc($services)) {
                $decoded = base64_decode((string) $service['service_name'], true);
                $name = $decoded === false ? (string) $service['service_name'] : $decoded;
                $type = strtolower(trim($service['service_type']));
                $label = '#' . (int) $service['service_id'] . ' · ' . $name . ' · ' . number_format((float) $service['service_price'], 0, '.', ' ') . ' UZS' . ($type === 'package' ? '' : ' / 1000');
                $serviceMeta[(int) $service['service_id']] = ['min' => (int) $service['service_min'], 'max' => (int) $service['service_max'], 'type' => $type, 'price' => (float) $service['service_price']];
                echo '<option value="' . (int) $service['service_id'] . '" data-name="' . funyapi_site_escape_html(mb_strtolower($name, 'UTF-8')) . '">' . funyapi_site_escape_html($label) . '</option>';
            }
            echo '</select></label><div class="fy-form-row"><label>' . funyapi_site_escape_html(funyapi_site_t('link')) . '<input type="url" name="link" placeholder="https://instagram.com/..." required maxlength="2048"></label><label>' . funyapi_site_escape_html(funyapi_site_t('quantity')) . '<input type="number" id="fy-quantity" name="quantity" min="1" value="1000" required></label></div><div class="fy-price-preview"><span>' . funyapi_site_escape_html(funyapi_site_t('price')) . '</span><strong id="fy-order-price">— UZS</strong><small id="fy-quantity-limits"></small></div><button class="fy-button" type="submit">' . funyapi_site_escape_html(funyapi_site_t('place_order')) . ' <span>→</span></button><div id="fy-order-status" class="fy-muted" aria-live="polite"></div></form>';
            echo '<script>window.FUNYAPI_ORDER={csrf:' . json_encode($csrf) . ',services:' . json_encode($serviceMeta) . '};(function(){var cfg=window.FUNYAPI_ORDER,s=document.getElementById("fy-service"),q=document.getElementById("fy-quantity"),price=document.getElementById("fy-order-price"),limits=document.getElementById("fy-quantity-limits"),search=document.getElementById("fy-service-search");function update(){var x=cfg.services[s.value];if(!x){price.textContent="— UZS";limits.textContent="";return;}q.min=x.type==="package"?1:x.min;q.max=x.type==="package"?1:x.max;if(x.type==="package")q.value=1;limits.textContent=x.type==="package"?"Package service":"Min "+x.min+" · Max "+x.max;var amount=x.type==="package"?x.price:x.price*(Number(q.value||0)/1000);price.textContent=(Math.round(amount*100)/100).toLocaleString("uz-UZ",{minimumFractionDigits:2,maximumFractionDigits:2})+" UZS";}s.onchange=update;q.oninput=update;search.oninput=function(){var v=this.value.toLocaleLowerCase();Array.prototype.forEach.call(s.options,function(o,i){if(i)o.hidden=v!==""&&!o.dataset.name.includes(v);});};document.getElementById("fy-checkout-form").onsubmit=function(e){e.preventDefault();var form=e.currentTarget,status=document.getElementById("fy-order-status"),button=form.querySelector("button[type=submit]"),payload={csrf:cfg.csrf,service_id:s.value,quantity:q.value,link:form.elements.link.value};button.disabled=true;status.textContent="Buyurtma yuborilmoqda…";fetch("/checkout",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify(payload)}).then(function(r){return r.json();}).then(function(d){if(d.ok){status.textContent=d.message+" ID: #"+d.order;window.location.href="/my-orders";}else status.textContent=d.error||"Xato";}).catch(function(){status.textContent="Tarmoq xatosi. Qayta urinib ko‘ring.";}).finally(function(){button.disabled=false;});};update();})();</script>';
        }
        echo '</section>';
    }
    if (empty($siteAccount['google_sub'])) {
        echo '<section class="fy-card fy-provider-link"><span>Google</span><div><h3>' . funyapi_site_escape_html(funyapi_site_t('connect_google')) . '</h3><p>' . funyapi_site_escape_html(funyapi_site_t('login_desc')) . '</p><div id="google-login"></div><div id="turnstile-container"></div></div></section><script src="https://accounts.google.com/gsi/client" async defer></script><script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" async defer></script><script>window.FUNYAPI_AUTH={csrf:' . json_encode($csrf) . ',googleClient:' . json_encode(GOOGLE_CLIENT_ID) . ',turnstileSite:' . json_encode(TURNSTILE_SITE_KEY) . '};(function(){var t=null,token="",cfg=window.FUNYAPI_AUTH;var timer=setInterval(function(){if(window.turnstile&&cfg.turnstileSite&&t===null){t=turnstile.render("#turnstile-container",{sitekey:cfg.turnstileSite,theme:"dark",callback:function(x){token=x;}});}if(window.google&&google.accounts&&google.accounts.id){clearInterval(timer);google.accounts.id.initialize({client_id:cfg.googleClient,callback:function(r){fetch("/auth/google",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify({csrf:cfg.csrf,credential:r.credential,turnstile:token})}).then(function(x){return x.json();}).then(function(d){if(d.ok)location.reload();else alert(d.error);});}});google.accounts.id.renderButton(document.getElementById("google-login"),{theme:"filled_black",size:"large",shape:"pill"});}},250);})();</script>';
    }
    echo '<section class="fy-card"><div class="fy-card-heading"><div><span class="fy-eyebrow">ACTIVITY</span><h2>' . funyapi_site_escape_html(funyapi_site_t('recent_orders')) . '</h2></div><a href="/my-orders">' . funyapi_site_escape_html(funyapi_site_t('orders')) . ' →</a></div><div class="fy-table-wrap"><table class="fy-table"><thead><tr><th>ID</th><th>' . funyapi_site_escape_html(funyapi_site_t('service')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('price')) . '</th><th>' . funyapi_site_escape_html(funyapi_site_t('status')) . '</th></tr></thead><tbody>';
    foreach ($orders as $order) {
        $serviceName = base64_decode((string) $order['service_name'], true);
        if ($serviceName === false) $serviceName = (string) $order['service_name'];
        echo '<tr><td>#' . (int) $order['order_id'] . '</td><td>' . funyapi_site_escape_html($serviceName) . '</td><td>' . number_format((float) $order['retail'], 0, '.', ' ') . ' UZS</td><td><span class="fy-tag">' . funyapi_site_escape_html($order['status']) . '</span></td></tr>';
    }
    if (!$orders) echo '<tr><td colspan="4">' . funyapi_site_escape_html(funyapi_site_t('no_orders')) . '</td></tr>';
    echo '</tbody></table></div></section>';
    if (funyapi_site_is_admin($siteAccount)) echo '<div class="fy-admin-link"><a href="/admin">' . funyapi_site_escape_html(funyapi_site_t('admin')) . ' →</a></div>';
    funyapi_site_footer();
    exit;
}

http_response_code(404);
require __DIR__ . '/404.php';

