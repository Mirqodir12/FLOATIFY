<?php

if (!defined('FUNYAPI_BOT_WEBHOOK')) {
    http_response_code(404);
    exit;
}

/*
 * User-facing SMM order flow. This file is included at the end of bot.php,
 * where the Telegram update, database connection and menu helpers are ready.
 */

if (strpos((string) $data, 'ordered=') === 0) {
    $parts = explode('=', $data);
    $serviceId = isset($parts[1]) ? (int) $parts[1] : 0;
    $serviceResult = $serviceId
        ? mysqli_query($connect, "SELECT * FROM services WHERE service_id = $serviceId AND service_status = 'on' LIMIT 1")
        : false;
    $service = $serviceResult ? mysqli_fetch_assoc($serviceResult) : null;

    if (!$service) {
        bot('answerCallbackQuery', [
            'callback_query_id' => $qid,
            'text' => "Xizmat topilmadi yoki vaqtincha o‘chirilgan.",
            'show_alert' => true
        ]);
    } else {
        $decodedName = base64_decode((string) $service['service_name'], true);
        $serviceName = htmlspecialchars($decodedName !== false ? $decodedName : '', ENT_QUOTES, 'UTF-8');
        $decodedDescription = base64_decode((string) $service['service_desc'], true);
        $description = $decodedDescription !== false
            ? htmlspecialchars($decodedDescription, ENT_QUOTES, 'UTF-8')
            : '';
        $minimum = (int) $service['service_min'];
        $maximum = (int) $service['service_max'];
        $serviceType = strtolower(trim($service['service_type']));
        $price = number_format((float) $service['service_price'], 0, '.', ' ');
        $priceLabel = $serviceType === 'package'
            ? "📦 Xizmat narxi: <b>$price so‘m</b>"
            : "💰 Narxi (1000 ta): <b>$price so‘m</b>";
        $bounds = $serviceType === 'package'
            ? ''
            : "\n🔽 Miqdor: <b>$minimum–$maximum</b>";

        $detail = "<b>🚀 Xizmat:</b> $serviceName\n\n"
            . "<b>🆔 Xizmat IDsi:</b> <code>" . (int) $service['service_id'] . "</code>\n"
            . $priceLabel . $bounds;
        if ($description !== '') {
            $detail .= "\n\n" . $description;
        }

        edit($chat_id, $message_id, $detail, json_encode([
            'inline_keyboard' => [[[
                'text' => '✅ Buyurtma berish',
                'callback_data' => 'aosdrder=' . (int) $service['service_id']
            ]]]
        ]));
    }
}

if (strpos((string) $data, 'aosdrder=') === 0 && $chat_id) {
    $parts = explode('=', $data);
    $serviceId = isset($parts[1]) ? (int) $parts[1] : 0;
    $serviceResult = $serviceId
        ? mysqli_query($connect, "SELECT * FROM services WHERE service_id = $serviceId AND service_status = 'on' LIMIT 1")
        : false;
    $service = $serviceResult ? mysqli_fetch_assoc($serviceResult) : null;
    $userId = (int) $chat_id;

    if (!$service) {
        bot('answerCallbackQuery', [
            'callback_query_id' => $qid,
            'text' => "Xizmat topilmadi yoki vaqtincha o‘chirilgan.",
            'show_alert' => true
        ]);
    } else {
        $draft = [
            'service_id' => (int) $service['service_id'],
            'service_name' => $service['service_name'],
            'service_price' => (float) $service['service_price'],
            'service_type' => strtolower(trim($service['service_type'])),
            'minimum' => (int) $service['service_min'],
            'maximum' => (int) $service['service_max']
        ];
        file_put_contents("user/$userId.smm_order", json_encode($draft, JSON_UNESCAPED_UNICODE));
        put("user/$userId.step", 'smm_order_link');
        bot('answerCallbackQuery', ['callback_query_id' => $qid]);
        sms($userId, "🔗 Buyurtma uchun havola yoki sahifa ID-sini yuboring.\n\nBekor qilish uchun /cancel yuboring.", $menu);
    }
}

if (($step === 'smm_order_link' || $step === 'smm_order_quantity') && isset($text) && $text === '/cancel' && $cid) {
    @unlink("user/$cid.smm_order");
    @unlink("user/$cid.step");
    sms($cid, "Buyurtma bekor qilindi.", $menu);
}

if ($step === 'smm_order_link' && isset($text) && $text !== '/cancel' && $cid) {
    $draft = json_decode(@file_get_contents("user/$cid.smm_order"), true);
    $link = trim((string) $text);

    if (!is_array($draft) || empty($draft['service_id'])) {
        @unlink("user/$cid.step");
        sms($cid, "Buyurtma ma’lumotlari topilmadi. Xizmatni qayta tanlang.", $menu);
    } elseif ($link === '' || strlen($link) > 2048) {
        sms($cid, "Havola bo‘sh bo‘lmasin va 2048 belgidan oshmasin. Qaytadan yuboring.", $menu);
    } else {
        $draft['link'] = $link;
        if ($draft['service_type'] === 'package') {
            $draft['quantity'] = 1;
            $draft['price'] = (float) $draft['service_price'];
            file_put_contents("user/$cid.smm_order", json_encode($draft, JSON_UNESCAPED_UNICODE));
            put("user/$cid.step", 'smm_order_confirm');
            send_smm_order_confirmation($cid, $draft);
        } elseif ((int) $draft['minimum'] === (int) $draft['maximum']) {
            $draft['quantity'] = (int) $draft['minimum'];
            $draft['price'] = round(((float) $draft['service_price'] / 1000) * $draft['quantity'], 2);
            file_put_contents("user/$cid.smm_order", json_encode($draft, JSON_UNESCAPED_UNICODE));
            put("user/$cid.step", 'smm_order_confirm');
            send_smm_order_confirmation($cid, $draft);
        } else {
            file_put_contents("user/$cid.smm_order", json_encode($draft, JSON_UNESCAPED_UNICODE));
            put("user/$cid.step", 'smm_order_quantity');
            $minimum = (int) $draft['minimum'];
            $maximum = (int) $draft['maximum'];
            sms($cid, "🔢 Buyurtma miqdorini yuboring.\nRuxsat etilgan miqdor: $minimum–$maximum ta.", $menu);
        }
    }
}

if ($step === 'smm_order_quantity' && isset($text) && $text !== '/cancel' && $cid) {
    $draft = json_decode(@file_get_contents("user/$cid.smm_order"), true);
    $quantity = filter_var(trim((string) $text), FILTER_VALIDATE_INT);

    if (!is_array($draft) || empty($draft['service_id'])) {
        @unlink("user/$cid.step");
        sms($cid, "Buyurtma ma’lumotlari topilmadi. Xizmatni qayta tanlang.", $menu);
    } elseif ($quantity === false || $quantity < (int) $draft['minimum'] || $quantity > (int) $draft['maximum']) {
        $minimum = (int) $draft['minimum'];
        $maximum = (int) $draft['maximum'];
        sms($cid, "Miqdor $minimum–$maximum oralig‘ida butun son bo‘lishi kerak.", $menu);
    } else {
        $draft['quantity'] = (int) $quantity;
        $draft['price'] = round(((float) $draft['service_price'] / 1000) * $draft['quantity'], 2);
        file_put_contents("user/$cid.smm_order", json_encode($draft, JSON_UNESCAPED_UNICODE));
        put("user/$cid.step", 'smm_order_confirm');
        send_smm_order_confirmation($cid, $draft);
    }
}

if ($data === 'smm_cancel' && $chat_id) {
    $userId = (int) $chat_id;
    @unlink("user/$userId.smm_order");
    @unlink("user/$userId.step");
    bot('answerCallbackQuery', ['callback_query_id' => $qid, 'text' => "Buyurtma bekor qilindi."]);
    edit($chat_id, $message_id, "❌ Buyurtma bekor qilindi.", null);
}

if ($data === 'smm_confirm' && $chat_id) {
    $userId = (int) $chat_id;
    $draftPath = "user/$userId.smm_order";
    $draft = json_decode(@file_get_contents($draftPath), true);
    $serviceId = is_array($draft) && isset($draft['service_id']) ? (int) $draft['service_id'] : 0;
    $serviceResult = $serviceId
        ? mysqli_query($connect, "SELECT * FROM services WHERE service_id = $serviceId AND service_status = 'on' LIMIT 1")
        : false;
    $service = $serviceResult ? mysqli_fetch_assoc($serviceResult) : null;

    if (!is_array($draft) || !$service || empty($draft['link']) || empty($draft['quantity'])) {
        bot('answerCallbackQuery', [
            'callback_query_id' => $qid,
            'text' => "Buyurtma ma’lumotlari eskirgan. Qaytadan boshlang.",
            'show_alert' => true
        ]);
        @unlink($draftPath);
        @unlink("user/$userId.step");
    } else {
        $providerId = (int) $service['api_service'];
        $providerResult = mysqli_query($connect, "SELECT * FROM providers WHERE id = $providerId LIMIT 1");
        $provider = $providerResult ? mysqli_fetch_assoc($providerResult) : null;
        $quantity = (int) $draft['quantity'];
        $minimum = (int) $service['service_min'];
        $maximum = (int) $service['service_max'];
        $serviceType = strtolower(trim($service['service_type']));
        $charge = $serviceType === 'package'
            ? (float) $service['service_price']
            : round(((float) $service['service_price'] / 1000) * $quantity, 2);
        $chargeSql = number_format($charge, 2, '.', '');

        if (!$provider || $quantity < 1 || ($serviceType !== 'package' && ($quantity < $minimum || $quantity > $maximum))) {
            bot('answerCallbackQuery', [
                'callback_query_id' => $qid,
                'text' => "Xizmat sozlamasi o‘zgargan. Qaytadan tanlang.",
                'show_alert' => true
            ]);
            @unlink($draftPath);
            @unlink("user/$userId.step");
        } else {
            mysqli_begin_transaction($connect);
            $balanceResult = mysqli_query($connect, "SELECT balance FROM users WHERE id = $userId FOR UPDATE");
            $user = $balanceResult ? mysqli_fetch_assoc($balanceResult) : null;

            if (!$user || (float) $user['balance'] < $charge) {
                mysqli_rollback($connect);
                bot('answerCallbackQuery', [
                    'callback_query_id' => $qid,
                    'text' => "Balansingizda mablag‘ yetarli emas.",
                    'show_alert' => true
                ]);
                @unlink($draftPath);
                @unlink("user/$userId.step");
            } else {
                $balanceUpdated = mysqli_query($connect, "UPDATE users SET balance = CAST(balance AS DECIMAL(20,2)) - $chargeSql WHERE id = $userId");
                $counterUpdated = mysqli_query($connect, "UPDATE settings SET ordercount = LAST_INSERT_ID(ordercount + 1) WHERE id = 1");
                $orderId = $counterUpdated ? (int) mysqli_insert_id($connect) : 0;
                $createdAt = mysqli_real_escape_string($connect, date('Y.m.d H:i:s'));
                $serviceIdForOrder = (int) $service['service_id'];
                $providerIdForOrder = (int) $provider['id'];
                $insertMyOrder = $orderId > 0 && $balanceUpdated
                    ? mysqli_query($connect, "INSERT INTO myorder (order_id, user_id, retail, status, service, order_create, last_check) VALUES ($orderId, '$userId', '$chargeSql', 'Processing', '$serviceIdForOrder', '$createdAt', '$createdAt')")
                    : false;
                $insertOrder = $insertMyOrder
                    ? mysqli_query($connect, "INSERT INTO orders (api_order, order_id, provider, status) VALUES ('', $orderId, $providerIdForOrder, 'Processing')")
                    : false;
                $insertNewOrder = $insertOrder
                    ? mysqli_query($connect, "INSERT INTO neworder (order_id, api_order_id, provider, user_id, retail, status, service, order_create, last_check) VALUES ($orderId, '', $providerIdForOrder, '$userId', '$chargeSql', 'Processing', '$serviceIdForOrder', '$createdAt', '$createdAt')")
                    : false;

                if (!$balanceUpdated || !$counterUpdated || !$insertMyOrder || !$insertOrder || !$insertNewOrder) {
                    mysqli_rollback($connect);
                    error_log('FunyAPI could not create a local order record.');
                    bot('answerCallbackQuery', [
                        'callback_query_id' => $qid,
                        'text' => "Buyurtmani saqlashda xatolik yuz berdi. Mablag‘ yechilmadi.",
                        'show_alert' => true
                    ]);
                } else {
                    mysqli_commit($connect);
                    $providerUrl = trim($provider['api_url']);
                    $providerUrlParts = parse_url($providerUrl);
                    $providerOrderId = null;

                    if (is_array($providerUrlParts)
                        && isset($providerUrlParts['scheme'], $providerUrlParts['host'])
                        && in_array(strtolower($providerUrlParts['scheme']), ['http', 'https'], true)) {
                        $query = http_build_query([
                            'key' => $provider['api_key'],
                            'action' => 'add',
                            'service' => $service['service_api'],
                            'link' => $draft['link'],
                            'quantity' => $quantity
                        ]);
                        $separator = strpos($providerUrl, '?') === false ? '?' : '&';
                        $context = stream_context_create(['http' => ['timeout' => 20, 'ignore_errors' => true]]);
                        $response = @file_get_contents($providerUrl . $separator . $query, false, $context);
                        $providerReply = $response ? json_decode($response, true) : null;
                        if (is_array($providerReply) && !empty($providerReply['order']) && empty($providerReply['error'])) {
                            $providerOrderId = (string) $providerReply['order'];
                        }
                    }

                    if ($providerOrderId === null) {
                        mysqli_begin_transaction($connect);
                        $failedAt = mysqli_real_escape_string($connect, date('Y.m.d H:i:s'));
                        mysqli_query($connect, "UPDATE users SET balance = CAST(balance AS DECIMAL(20,2)) + $chargeSql WHERE id = $userId");
                        mysqli_query($connect, "UPDATE myorder SET status = 'Canceled', last_check = '$failedAt' WHERE order_id = $orderId");
                        mysqli_query($connect, "UPDATE orders SET status = 'Canceled' WHERE order_id = $orderId");
                        mysqli_query($connect, "UPDATE neworder SET status = 'Canceled', last_check = '$failedAt' WHERE order_id = $orderId");
                        mysqli_commit($connect);
                        @unlink($draftPath);
                        @unlink("user/$userId.step");
                        bot('answerCallbackQuery', ['callback_query_id' => $qid]);
                        sms($userId, "❌ Provayder buyurtmani qabul qilmadi yoki javob bermadi. Yechilgan mablag‘ balansingizga qaytarildi.", $menu);
                    } else {
                        $providerOrderIdSql = mysqli_real_escape_string($connect, $providerOrderId);
                        $updatedAt = mysqli_real_escape_string($connect, date('Y.m.d H:i:s'));
                        mysqli_query($connect, "UPDATE orders SET api_order = '$providerOrderIdSql', status = 'Pending' WHERE order_id = $orderId");
                        mysqli_query($connect, "UPDATE myorder SET status = 'Pending', last_check = '$updatedAt' WHERE order_id = $orderId");
                        mysqli_query($connect, "UPDATE neworder SET api_order_id = '$providerOrderIdSql', status = 'Pending', last_check = '$updatedAt' WHERE order_id = $orderId");
                        $eventType = 'bot_order_created';
                        $eventDetail = 'Order #' . $orderId . ' · service ' . $serviceIdForOrder . ' · ' . $chargeSql . ' UZS';
                        $eventStatement = mysqli_prepare($connect, 'INSERT INTO site_events (account_id, event_type, detail, created_at) VALUES ((SELECT account_id FROM site_accounts WHERE telegram_user_id = ? LIMIT 1), ?, ?, ?)');
                        if ($eventStatement) {
                            mysqli_stmt_bind_param($eventStatement, 'ssss', $userId, $eventType, $eventDetail, $updatedAt);
                            mysqli_stmt_execute($eventStatement);
                            mysqli_stmt_close($eventStatement);
                        }
                        funyapi_site_notify_admin("FunyAPI bot: yangi buyurtma #$orderId · xizmat $serviceIdForOrder · $chargeSql UZS");
                        @unlink($draftPath);
                        @unlink("user/$userId.step");
                        bot('answerCallbackQuery', ['callback_query_id' => $qid]);
                        bot('deleteMessage', ['chat_id' => $chat_id, 'message_id' => $message_id]);
                        sms($userId, "✅ Buyurtmangiz qabul qilindi.\n\n🆔 Buyurtma IDsi: <code>$orderId</code>\n💰 To‘lov: <b>" . number_format($charge, 0, '.', ' ') . " so‘m</b>", $menu);
                    }
                }
            }
        }
    }
}

