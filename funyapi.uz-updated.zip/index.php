<?php

$requestPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
$requestPath = is_string($requestPath) ? $requestPath : '/';

$scriptDirectory = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/'));
$basePath = rtrim($scriptDirectory, '/');
if ($basePath !== '' && $basePath !== '/' && strpos($requestPath, $basePath . '/') === 0) {
    $requestPath = substr($requestPath, strlen($basePath));
} elseif ($basePath !== '' && $basePath !== '/' && $requestPath === $basePath) {
    $requestPath = '/';
}

$route = array_values(array_filter(explode('/', trim($requestPath, '/')), 'strlen'));
$controllerDirectory = __DIR__ . '/app/controller/';

if (!$route) {
    require $controllerDirectory . 'index.php';
} elseif (isset($route[0], $route[1]) && $route[0] === 'api' && $route[1] === 'v2') {
    require $controllerDirectory . 'api.php';
} elseif (isset($route[0]) && $route[0] === 'services') {
    require $controllerDirectory . 'services.php';
} elseif (isset($route[0]) && $route[0] === 'orders') {
    require $controllerDirectory . 'orders.php';
} elseif (isset($route[0]) && $route[0] === 'api') {
    require $controllerDirectory . 'api2.php';
} elseif (isset($route[0]) && in_array($route[0], ['login', 'auth', 'account', 'logout', 'admin', 'checkout', 'support', 'my-orders'], true)) {
    require $controllerDirectory . 'site.php';
} else {
    require $controllerDirectory . '404.php';
}

