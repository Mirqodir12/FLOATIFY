<?php


require_once __DIR__ . '/sql_connect.php';

function sms($id,$tx,$m){
return bot('sendMessage',[
'chat_id'=>$id,
'text'=>$tx,
'parse_mode'=>"HTML",
'reply_markup'=>$m,
]);
}

function get($h){
return file_get_contents($h);
}

function bot($method,$datas=[]){
    if (API_KEY === '') {
        error_log('FunyAPI Telegram notification skipped because TELEGRAM_BOT_TOKEN is not configured.');
        return false;
    }
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        error_log('FunyAPI Telegram request failed: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }else{
        curl_close($ch);
        return json_decode($res);
    }
}

header('Content-type:application/json');
$key = isset($_REQUEST['key']) ? $_REQUEST['key'] : '';
$service = isset($_REQUEST['service']) ? $_REQUEST['service'] : '';
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
$answer_number = isset($_REQUEST['answer_number']) ? $_REQUEST['answer_number'] : '';
$username = isset($_REQUEST['username']) ? $_REQUEST['username'] : '';
$link = isset($_REQUEST['link']) ? $_REQUEST['link'] : '';
$order = isset($_REQUEST['order']) ? $_REQUEST['order'] : '';
$quantity = isset($_REQUEST['quantity']) ? $_REQUEST['quantity'] : '';
$key = mysqli_real_escape_string($connect, (string) $key);
$service = (int) $service;
$order = (int) $order;
$quantity = filter_var($quantity, FILTER_VALIDATE_INT);


if($action == "balance"){
$b = mysqli_query($connect,"SELECT * FROM users WHERE api_key = '$key'");
$c = mysqli_num_rows($b);
$res = mysqli_fetch_assoc($b);
if($c){
echo json_encode(['balance'=>$res['balance'],'currency'=>"UZS"]);
}else{
echo json_encode(['error'=>"Incorrect API key"]);
}
exit();
}

if($action == "add") {
if ($quantity === false || $quantity < 1) {
    echo json_encode(['error'=>"Quantity must be a positive whole number"]);
    exit;
}
$b = mysqli_query($connect,"SELECT * FROM users WHERE api_key = '$key' && status = 'active'");
$c = mysqli_num_rows($b);
$res = mysqli_fetch_assoc($b);
if($c){
$s = mysqli_query($connect,"SELECT * FROM `services` WHERE service_id = '$service' AND service_status='on'");
$cy = mysqli_num_rows($s);
$resy = mysqli_fetch_assoc($s);
if($cy){
if($link){
if($quantity>=$resy['service_min']){
if($quantity<=$resy['service_max']){
$narxi=$resy['service_price']/1000*$quantity;
if($res['balance']>=$narxi){
$api = $resy['api_service'];
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = '$api'"));
$surl = $m['api_url'];
$skey =$m['api_key'];
$sid = $resy['service_api'];
                $providerUrl = trim($surl);
                $providerUrlParts = parse_url($providerUrl);
                if (!is_array($providerUrlParts) || !isset($providerUrlParts['scheme'], $providerUrlParts['host']) || !in_array(strtolower($providerUrlParts['scheme']), ['http', 'https'], true)) {
                    echo json_encode(['error'=>"Provider URL is invalid"]);
                    exit;
                }
                $providerQuery = http_build_query(['key'=>$skey,'action'=>'add','service'=>$sid,'link'=>$link,'quantity'=>$quantity]);
                $providerSeparator = strpos($providerUrl, '?') === false ? '?' : '&';
                $providerContext = stream_context_create(['http'=>['timeout'=>20,'ignore_errors'=>true]]);
                $providerResponse = @file_get_contents($providerUrl.$providerSeparator.$providerQuery, false, $providerContext);
                $j = $providerResponse ? json_decode($providerResponse, true) : null;
$jid=$j['order'];
$jer=$j['error'];
if(empty($jid)){
echo json_encode(['error'=>"Unknown error, please try again later"]);
exit;
}else{
                $counterUpdated = mysqli_query($connect,"UPDATE settings SET ordercount=LAST_INSERT_ID(ordercount + 1) WHERE id=1");
                $order_id = $counterUpdated ? (int) mysqli_insert_id($connect) : 0;
                if ($order_id < 1) {
                    error_log('FunyAPI could not allocate an order ID after provider acceptance.');
                    echo json_encode(['error'=>"Order accepted by provider but could not be saved. Contact support."]);
                    exit;
                }
                $ball = (float) $res['balance']-$narxi;
$sav = date("Y.m.d H:i:s");
mysqli_query($connect,"UPDATE `users` SET balance='$ball' WHERE api_key = '$key'");
mysqli_query($connect,"INSERT INTO myorder(`order_id`,`user_id`,`retail`,`status`,`service`,`order_create`,`last_check`) VALUES ('$order_id','$res[id]','$narxi','Pending','$service','$sav','$sav');");
mysqli_query($connect,"INSERT INTO orders(`api_order`,`order_id`,`provider`,`status`) VALUES ('$jid','$order_id','$api','Pending');");
mysqli_query($connect,"INSERT INTO neworder(`order_id`,`api_order_id`,`provider`,`user_id`,`retail`,`status`,`service`,`order_create`,`last_check`) VALUES ('$order_id','$jid','$api','$res[id]','$narxi','Pending','$service','$sav','$sav');");
echo json_encode(['order'=>$order_id,'charge'=>$narxi,'currency'=>"UZS"]);
sms("@gramapi_orders","<b>🆕 API | Yangi buyurtma:</b> <code>$order_id</code>

<b>🛍 Xizmat IDsi:</b> <code>$service</code>
<b>💰 Buyurtma narxi:</b> $narxi so'm
<b>👤 Buyurtmachi:</b> <a href='tg://user?id=".$res['id']."'>".$res['id']."</a>
<b>⏺ Oldingi balansi:</b> ".$res['balance']."  so'm
<b>➡️ Yangi balansi:</b> $ball so'm",null);
exit;
}

//true
exit;
}else{
		echo json_encode(['error'=>"Not enough funds on balance"]);
		exit;
         }
}else{
		echo json_encode(['error'=>"Quantity less than maximum ".$resy['service_max']]);
		exit;
		 }
}else{
		echo json_encode(['error'=>"Quantity less than minimal ".$resy['service_min']]);
	    exit;
         }
}else{
		echo json_encode(['error'=>"Bad link"]);
		exit;
		 }
}else{
        echo json_encode(['error'=>"Incorrect service ID"]);
        exit;
         }
}else{
         echo json_encode(['error'=>"invalid API key"]);
         exit;
}
}


if($action == "services"){
$b = mysqli_query($connect,"SELECT * FROM users WHERE api_key = '$key'");
$c = mysqli_num_rows($b);
$res = mysqli_fetch_assoc($b);
if($c){
$s = mysqli_query($connect,"SELECT * FROM `services`");
while($a = mysqli_fetch_assoc($s)){
	$cid = $a['category_id'];
	$ca = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM cates WHERE cate_id = $cid"));
	$categ = $ca['category_id'];
	$cas= mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM categorys WHERE category_id = $categ"));
$category=base64_decode($cas['category_name'])." ".base64_decode($ca['name']);
	
$name = base64_decode($a['service_name']);
$detail = json_decode($a["api_detail"],true);
$arr [] =['service'=>$a['service_id'],'category'=>$category,"name"=>$name,"rate"=>$a['service_price'],"min"=>$a['service_min'],"max"=>$a['service_max'],"type"=>$a['service_type'],"refill"=>$detail['refill'],"cancel"=>$detail['cancel'],"dripfeed"=>$detail['dripfeed']];
}
echo json_encode($arr,JSON_UNESCAPED_UNICODE);
}else{
echo json_encode(['error'=>"Incorrect API key"]);
}
exit();
}

if($action=="orders"){
$b = mysqli_query($connect,"SELECT * FROM users WHERE api_key = '$key'");
$c = mysqli_num_rows($b);
$res = mysqli_fetch_assoc($b);
if($c){
$id =$res['id'];
$q = mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $id");

while($d = mysqli_fetch_assoc($q)){
$h[]=['customer'=>$d['user_id'],'service'=>$d['service'],'order'=>$d['order_id'],'status'=>$d['status'],'charge'=>$d['retail'],'currency'=>"UZS"];

}
echo $h ? json_encode($h,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) : json_encode(['error'=>"No orders"]);
}else{
echo json_encode(array('error'=>"Incorrect API Key"));
}

exit;
}

if($action=="status"){
$b = mysqli_query($connect,"SELECT * FROM `users` WHERE api_key = '$key'");
$c = mysqli_num_rows($b);
$res = mysqli_fetch_assoc($b);

if($c){
if(isset($_GET['orders']) && is_string($_GET['orders'])){
$order_ids = explode(',', $_GET['orders']);
if(is_array($order_ids)){
$data = [];

$id =$res['id'];
foreach($order_ids as $order_id){
if(!is_numeric($order_id)){
$data[$order_id]=array('error'=>$order_id." is not a number");
}else{
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `myorder` WHERE order_id = $order_id AND user_id = $id"));


$resi = mysqli_query($connect, "SELECT * FROM orders WHERE order_id = $order_id");
$stati = mysqli_fetch_assoc($resi);
$prv = $stati['provider'];
$a = mysqli_query($connect,"SELECT * FROM providers WHERE id = $prv");
$c = mysqli_fetch_assoc($a);
$prg = $stati['provider'];
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = '$prg'"));
$surl = $m['api_url'];
$skey =$m['api_key'];
                $statusUrl = $surl . (strpos($surl, '?') === false ? '?' : '&') . http_build_query(['key'=>$skey,'action'=>'status','order'=>$stati['api_order']]);
                $apiResponse = @file_get_contents($statusUrl, false, stream_context_create(['http'=>['timeout'=>20,'ignore_errors'=>true]]));
                $api = $apiResponse ? json_decode($apiResponse, 1) : [];



if(empty($rew)){
$data[$order_id]=array('error'=>"Incorrect order ID");
}else{
$data[$order_id]=array('order'=>$order_id,'status'=>$rew['status'],'start_count'=>$api['start_count'] ? $api['start_count'] : "0",'remains'=>$api['remains'] ? $api['remains'] : "0",'charge'=>$rew['retail'],'currency'=>"UZS");
}
}
}
}
}else{
if($order > 0){
$id =$res['id'];
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `myorder` WHERE order_id = $order AND user_id = $id"));
if(empty($rew)){
$data=array('error'=>"Incorrect order ID");
}else{
	
$resi = mysqli_query($connect, "SELECT * FROM orders WHERE order_id = $order");
$stati = mysqli_fetch_assoc($resi);
$prv = $stati['provider'];
$a = mysqli_query($connect,"SELECT * FROM providers WHERE id = $prv");
$c = mysqli_fetch_assoc($a);
$prg = $stati['provider'];
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = '$prg'"));
$surl = $m['api_url'];
$skey =$m['api_key'];
                $statusUrl = $surl . (strpos($surl, '?') === false ? '?' : '&') . http_build_query(['key'=>$skey,'action'=>'status','order'=>$stati['api_order']]);
                $apiResponse = @file_get_contents($statusUrl, false, stream_context_create(['http'=>['timeout'=>20,'ignore_errors'=>true]]));
                $api = $apiResponse ? json_decode($apiResponse, 1) : [];

	
$data=array('order'=>$order,'status'=>$rew['status'],'start_count'=>$api['start_count'] ? $api['start_count'] : "0",'remains'=>$api['remains'] ? $api['remains'] : "0",'charge'=>$rew['retail'],'currency'=>"UZS");
}
}
}
}else{
echo json_encode(['error'=>"Incorrect API key"]);
exit;
}
echo $data ? json_encode($data,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) : json_encode(['error'=>"Invalid order ID"]);
exit;
}


echo json_encode(['error'=>"Incorrect request"]);
