-- Run once on an existing database. Safe to re-run if a column already exists.
SET @db_name = DATABASE();

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'settings' AND COLUMN_NAME = 'users') = 0,
    'ALTER TABLE `settings` ADD COLUMN `users` int NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

-- Make each Telegram identity map to exactly one shared bot/site user.
SET @duplicate_telegram_ids = (SELECT COUNT(*) FROM (SELECT `id` FROM `users` GROUP BY `id` HAVING COUNT(*) > 1) AS duplicate_ids);
SET @has_telegram_unique = (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND INDEX_NAME = 'uq_users_telegram_id');
SET @sql = IF(@duplicate_telegram_ids = 0 AND @has_telegram_unique = 0,
    'ALTER TABLE `users` ADD UNIQUE KEY `uq_users_telegram_id` (`id`(191))', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'settings' AND COLUMN_NAME = 'ordercount') = 0,
    'ALTER TABLE `settings` ADD COLUMN `ordercount` int NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND COLUMN_NAME = 'api_status') = 0,
    'ALTER TABLE `users` ADD COLUMN `api_status` varchar(20) NOT NULL DEFAULT ''on''', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND COLUMN_NAME = 'refnum') = 0,
    'ALTER TABLE `users` ADD COLUMN `refnum` int NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND COLUMN_NAME = 'ban') = 0,
    'ALTER TABLE `users` ADD COLUMN `ban` tinyint unsigned NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE funyapi_stmt FROM @sql;
EXECUTE funyapi_stmt;
DEALLOCATE PREPARE funyapi_stmt;

CREATE TABLE IF NOT EXISTS `neworder` (
  `order_id` int NOT NULL,
  `api_order_id` text NOT NULL,
  `provider` int NOT NULL,
  `user_id` text NOT NULL,
  `retail` text NOT NULL,
  `status` text NOT NULL,
  `service` text NOT NULL,
  `order_create` text,
  `last_check` text,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

UPDATE `settings`
SET `users` = GREATEST(`users`, COALESCE((SELECT MAX(`user_id`) FROM `users`), 0), (SELECT COUNT(*) FROM `users`)),
    `ordercount` = GREATEST(
      `ordercount`,
      COALESCE((SELECT MAX(`order_id`) FROM `myorder`), 0),
      COALESCE((SELECT MAX(`order_id`) FROM `orders`), 0)
    )
WHERE `id` = 1;

-- Google site accounts, Telegram account linking, and admin audit trail.
CREATE TABLE IF NOT EXISTS `site_accounts` (
  `account_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `google_sub` varchar(255) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `display_name` varchar(200) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user',
  `is_active` tinyint unsigned NOT NULL DEFAULT 1,
  `telegram_user_id` bigint DEFAULT NULL,
  `link_code_hash` char(64) DEFAULT NULL,
  `link_expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `uq_site_google_sub` (`google_sub`),
  UNIQUE KEY `uq_site_telegram_user` (`telegram_user_id`),
  UNIQUE KEY `uq_site_link_code` (`link_code_hash`),
  KEY `idx_site_email` (`email`),
  KEY `idx_site_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `site_accounts`
  MODIFY `google_sub` varchar(255) DEFAULT NULL,
  MODIFY `email` varchar(254) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `site_events` (
  `event_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(48) NOT NULL,
  `detail` varchar(1000) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `idx_site_event_created` (`created_at`),
  KEY `idx_site_event_type` (`event_type`),
  KEY `idx_site_event_account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
