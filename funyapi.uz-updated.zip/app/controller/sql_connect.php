<?php
ob_start();
require_once dirname(__DIR__) . '/config.php';

$siteHost = isset($_SERVER['HTTP_HOST']) ? trim((string) $_SERVER['HTTP_HOST']) : '';
$site_url = preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*(?::[0-9]{1,5})?$/iD', $siteHost) ? $siteHost : '';
$bot = 'FunyAPIBot';

if (DB_USERNAME === '' || DB_NAME === '') {
    error_log('FunyAPI database configuration is incomplete. Set DB_USER and DB_NAME in .env.');
    http_response_code(503);
    exit('Xizmat vaqtincha mavjud emas. Ma’lumotlar bazasi sozlamalarini tekshiring.');
}

mysqli_report(MYSQLI_REPORT_OFF);
$connect = @mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT);
if (!$connect) {
    error_log('FunyAPI database connection failed: ' . mysqli_connect_error());
    http_response_code(503);
    exit('Xizmat vaqtincha mavjud emas. Ma’lumotlar bazasiga ulanishni tekshiring.');
}

if (!mysqli_set_charset($connect, 'utf8mb4')) {
    error_log('FunyAPI could not set the database character set to utf8mb4.');
}

$settingsResult = mysqli_query($connect, "SELECT * FROM `settings` WHERE id = 1");
$row = $settingsResult ? mysqli_fetch_assoc($settingsResult) : null;
if (!$row) {
    error_log('FunyAPI settings row with id=1 is missing. Import app/db.sql or restore the settings row.');
    http_response_code(503);
    exit('Xizmat sozlamalari topilmadi. Ma’lumotlar bazasini sozlash kerak.');
}

$theme = isset($row['site_theme']) ? $row['site_theme'] : 'Eternity';
$style = isset($row['site_style']) ? $row['site_style'] : 'theme8.0';
