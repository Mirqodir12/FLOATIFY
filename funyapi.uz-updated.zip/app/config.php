<?php

/*
 * Local settings are read from the project-root .env file. Server environment
 * variables take precedence, so this also works on hosts that manage env vars.
 */
$funyapiEnvFile = dirname(__DIR__) . '/.env';
if (is_file($funyapiEnvFile) && is_readable($funyapiEnvFile)) {
    $funyapiEnvLines = file($funyapiEnvFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($funyapiEnvLines as $funyapiEnvLine) {
        $funyapiEnvLine = trim($funyapiEnvLine);
        if ($funyapiEnvLine === '' || substr($funyapiEnvLine, 0, 1) === '#') {
            continue;
        }

        $funyapiEnvParts = explode('=', $funyapiEnvLine, 2);
        if (count($funyapiEnvParts) !== 2) {
            continue;
        }

        $funyapiEnvName = trim($funyapiEnvParts[0]);
        if (!preg_match('/^[A-Z0-9_]+$/', $funyapiEnvName) || getenv($funyapiEnvName) !== false) {
            continue;
        }

        $funyapiEnvValue = trim($funyapiEnvParts[1]);
        if (strlen($funyapiEnvValue) >= 2) {
            $funyapiFirstQuote = substr($funyapiEnvValue, 0, 1);
            $funyapiLastQuote = substr($funyapiEnvValue, -1);
            if (($funyapiFirstQuote === '"' && $funyapiLastQuote === '"') || ($funyapiFirstQuote === "'" && $funyapiLastQuote === "'")) {
                $funyapiEnvValue = substr($funyapiEnvValue, 1, -1);
            }
        }

        putenv($funyapiEnvName . '=' . $funyapiEnvValue);
        $_ENV[$funyapiEnvName] = $funyapiEnvValue;
    }
}

if (!function_exists('funyapi_env')) {
    function funyapi_env($name, $default = '')
    {
        $value = getenv($name);
        return ($value === false || $value === '') ? $default : $value;
    }
}

if (!defined('DB_SERVER')) {
    define('DB_SERVER', funyapi_env('DB_HOST', 'localhost'));
    define('DB_PORT', (int) funyapi_env('DB_PORT', '3306'));
    define('DB_USERNAME', funyapi_env('DB_USER'));
    define('DB_PASSWORD', funyapi_env('DB_PASSWORD'));
    define('DB_NAME', funyapi_env('DB_NAME'));
}

if (!defined('API_KEY')) {
    define('API_KEY', funyapi_env('TELEGRAM_BOT_TOKEN'));
}

if (!defined('GOOGLE_CLIENT_ID')) {
    define('GOOGLE_CLIENT_ID', trim(funyapi_env('GOOGLE_CLIENT_ID')));
}

if (!defined('TURNSTILE_SITE_KEY')) {
    define('TURNSTILE_SITE_KEY', trim(funyapi_env('TURNSTILE_SITE_KEY')));
}

if (!defined('TURNSTILE_SECRET_KEY')) {
    define('TURNSTILE_SECRET_KEY', trim(funyapi_env('TURNSTILE_SECRET_KEY')));
}

if (!defined('SITE_ADMIN_EMAILS')) {
    define('SITE_ADMIN_EMAILS', trim(funyapi_env('SITE_ADMIN_EMAILS')));
}

if (!defined('BOT_ADMIN_ID')) {
    define('BOT_ADMIN_ID', trim(funyapi_env('BOT_ADMIN_ID', '5393908253')));
}

if (!defined('TELEGRAM_BOT_USERNAME')) {
    define('TELEGRAM_BOT_USERNAME', ltrim(trim(funyapi_env('TELEGRAM_BOT_USERNAME', 'FunyAPIBot')), '@'));
}

